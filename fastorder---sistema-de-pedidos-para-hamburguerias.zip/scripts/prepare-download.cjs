const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');

async function main() {
  const rootDir = path.resolve(__dirname, '..');
  const distDir = path.resolve(rootDir, 'dist');
  const publicDir = path.resolve(rootDir, 'public');
  const downloadDir = path.resolve(publicDir, 'downloadable-site');

  if (!fs.existsSync(distDir)) {
    console.error('dist directory does not exist');
    process.exit(1);
  }

  // 1. Find assets
  const assetsDir = path.join(distDir, 'assets');
  const files = fs.readdirSync(assetsDir);
  const jsFile = files.find(f => f.endsWith('.js'));
  const cssFile = files.find(f => f.endsWith('.css'));

  if (!jsFile || !cssFile) {
    console.error('JS or CSS asset not found in dist/assets');
    process.exit(1);
  }

  const jsContent = fs.readFileSync(path.join(assetsDir, jsFile), 'utf8');
  const cssContent = fs.readFileSync(path.join(assetsDir, cssFile), 'utf8');

  // 2. Base clean HTML template
  const cleanStandaloneHtml = `<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FastOrder - Sistema de Pedidos para Hamburguerias</title>
    <meta name="description" content="Sistema completo de pedidos online com cardápio estilo Netflix, combos animados, carrinho, checkout inteligente e envio automático para o WhatsApp." />
    <meta property="og:title" content="FastOrder - Sistema de Pedidos para Hamburguerias" />
    <meta property="og:description" content="Sistema completo de pedidos online com cardápio estilo Netflix, combos animados, carrinho, checkout inteligente e envio automático para o WhatsApp." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style id="fastorder-styles">
${cssContent}
    </style>
  </head>
  <body class="bg-[#0D0D0E] text-[#F3F4F6] antialiased selection:bg-[#E6392F] selection:text-white">
    <div id="root"></div>
    <script type="module">
${jsContent}
    </script>
  </body>
</html>
`;

  // Write standalone HTML to dist/index.html, dist/abrir-direto.html, and public/
  fs.writeFileSync(path.join(distDir, 'index.html'), cleanStandaloneHtml, 'utf8');
  fs.writeFileSync(path.join(distDir, 'abrir-direto.html'), cleanStandaloneHtml, 'utf8');
  fs.writeFileSync(path.join(publicDir, 'index.html'), cleanStandaloneHtml, 'utf8');
  fs.writeFileSync(path.join(publicDir, 'cardapio-fastorder.html'), cleanStandaloneHtml, 'utf8');

  // Also prepare root index.html:
  // It should support BOTH Vite development mode (when served by Vite via HTTP)
  // AND direct double-click execution (when opened via file:// as in C:/Users/.../index.html)
  const rootHtml = `<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>FastOrder - Sistema de Pedidos para Hamburguerias</title>
    <meta name="description" content="Sistema completo de pedidos online com cardápio estilo Netflix, combos animados, carrinho, checkout inteligente e envio automático para o WhatsApp." />
    <meta property="og:title" content="FastOrder - Sistema de Pedidos para Hamburguerias" />
    <meta property="og:description" content="Sistema completo de pedidos online com cardápio estilo Netflix, combos animados, carrinho, checkout inteligente e envio automático para o WhatsApp." />
    <meta property="og:type" content="website" />
    <meta name="twitter:card" content="summary_large_image" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style id="fastorder-offline-styles">
${cssContent}
    </style>
  </head>
  <body class="bg-[#0D0D0E] text-[#F3F4F6] antialiased selection:bg-[#E6392F] selection:text-white">
    <div id="root"></div>

    <!-- Vite dev mode entry point -->
    <script type="module" src="/src/main.tsx"></script>

    <!-- Standalone fallback: runs automatically if file is opened directly via file:// (double-click in Downloads) -->
    <script type="module">
      if (window.location.protocol === 'file:') {
${jsContent}
      }
    </script>
  </body>
</html>
`;
  fs.writeFileSync(path.join(rootDir, 'index.html'), rootHtml, 'utf8');

  // 3. Generate Windows & Mac launchers
  const batContent = `@echo off
echo ===================================================
echo     Abrindo FastOrder Gourmet no seu Navegador
echo ===================================================
start "" "index.html"
`;
  fs.writeFileSync(path.join(distDir, 'CLIQUE-PARA-ABRIR-WINDOWS.bat'), batContent, 'utf8');

  const shContent = `#!/bin/bash
open index.html 2>/dev/null || xdg-open index.html 2>/dev/null || google-chrome index.html 2>/dev/null
`;
  fs.writeFileSync(path.join(distDir, 'CLIQUE-PARA-ABRIR-MAC-LINUX.sh'), shContent, 'utf8');

  // 4. Generate README and instructions
  const readmeContent = `# FastOrder Gourmet - Cardápio Digital & Delivery

Parabéns! Seu site está 100% pronto para uso e publicação.

---

## ⚡ COMO ABRIR NO SEU COMPUTADOR AGORA (SEM INSTALAR NADA):
- **Opção 1**: Dê 2 cliques no arquivo **\`index.html\`** (ou **\`abrir-direto.html\`**). Ele abrirá imediatamente no seu navegador (Chrome, Edge, Firefox, etc.) sem erro e sem precisar de servidor!
- **Opção 2 (Windows)**: Dê 2 cliques em **\`CLIQUE-PARA-ABRIR-WINDOWS.bat\`**.

---

## 🌐 COMO COLOCAR O SITE NA INTERNET (GRÁTIS EM 2 MINUTOS):

### Opção A: Vercel (Recomendado - 100% Grátis com HTTPS)
1. Crie uma conta em https://vercel.com
2. Clique em "Add New Project" e envie esta pasta ou conecte seu GitHub.
3. Clique em "Deploy" e o site estará online em segundos com domínio grátis!

### Opção B: Netlify (Arraste e Solte)
1. Crie uma conta em https://netlify.com
2. Na página principal, arraste esta pasta inteira para a área "Drop your site here".
3. Pronto! O site entra no ar na hora.

### Opção C: Hospedagem com cPanel / Hostinger / Locaweb
1. Acesse o gerenciador de arquivos da sua hospedagem.
2. Envie todos os arquivos desta pasta para dentro da pasta \`public_html\`.

---
© FastOrder Gourmet - Todos os direitos reservados.
`;
  fs.writeFileSync(path.join(distDir, 'LEIAME.txt'), readmeContent, 'utf8');
  fs.writeFileSync(path.join(distDir, 'README.md'), readmeContent, 'utf8');

  // 5. Configs for Vercel & Netlify
  fs.writeFileSync(path.join(distDir, 'vercel.json'), JSON.stringify({
    routes: [{ handle: "filesystem" }, { src: "/.*", dest: "/index.html" }]
  }, null, 2), 'utf8');

  fs.writeFileSync(path.join(distDir, 'netlify.toml'), `[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
`, 'utf8');

  // 6. Ensure public/downloadable-site directory exists
  if (!fs.existsSync(downloadDir)) {
    fs.mkdirSync(downloadDir, { recursive: true });
  }

  fs.writeFileSync(path.join(downloadDir, 'index.html'), cleanStandaloneHtml, 'utf8');
  fs.writeFileSync(path.join(downloadDir, 'abrir-direto.html'), cleanStandaloneHtml, 'utf8');

  // 7. Create pre-built ZIP using JSZip
  const zip = new JSZip();

  function addDirToZip(currentDir, zipFolder) {
    const items = fs.readdirSync(currentDir);
    for (const item of items) {
      if (item.endsWith('.zip')) continue;
      const fullPath = path.join(currentDir, item);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        addDirToZip(fullPath, zipFolder.folder(item));
      } else {
        zipFolder.file(item, fs.readFileSync(fullPath));
      }
    }
  }

  addDirToZip(distDir, zip);

  const zipBuffer = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 }
  });

  const zipDest = path.join(publicDir, 'fastorder-site-completo.zip');
  fs.writeFileSync(zipDest, zipBuffer);
  fs.writeFileSync(path.join(downloadDir, 'fastorder-site-completo.zip'), zipBuffer);

  console.log('✅ Package created successfully:');
  console.log('- dist/index.html (standalone):', (cleanStandaloneHtml.length / 1024).toFixed(2), 'KB');
  console.log('- public/fastorder-site-completo.zip:', (zipBuffer.length / 1024 / 1024).toFixed(2), 'MB');
}

main().catch(err => {
  console.error('Error preparing download:', err);
  process.exit(1);
});
