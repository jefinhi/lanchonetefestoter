/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { HeroCombos } from './components/HeroCombos';
import { CategoryFilterBar, FilterType } from './components/CategoryFilterBar';
import { NetflixRow } from './components/NetflixRow';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { MobileCartBar } from './components/MobileCartBar';
import { Toast } from './components/Toast';
import { Testimonials } from './components/Testimonials';
import { Footer } from './components/Footer';
import { products, defaultRestaurantConfig } from './data/products';
import { Product, CartItem, Addon, RestaurantConfig } from './types';
import { Plus, Eye } from 'lucide-react';

export default function App() {
  // Config & State
  const [config] = useState<RestaurantConfig>(() => {
    const saved = localStorage.getItem('fastorder_config');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return defaultRestaurantConfig;
  });

  // Cart State with LocalStorage persistence
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('fastorder_cart_items');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return [];
  });

  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [discountAmount, setDiscountAmount] = useState(0);

  // Modals & Drawers
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  // Filters & Search
  const [selectedFilter, setSelectedFilter] = useState<FilterType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Save cart to LocalStorage
  useEffect(() => {
    localStorage.setItem('fastorder_cart_items', JSON.stringify(cart));
  }, [cart]);

  // Cart Totals
  const cartCount = useMemo(() => cart.reduce((sum, item) => sum + item.quantity, 0), [cart]);
  const cartSubtotal = useMemo(() => cart.reduce((sum, item) => sum + item.totalPrice, 0), [cart]);

  // Add customized item to cart
  const handleAddToCart = (
    product: Product,
    quantity: number,
    selectedAddons: Addon[],
    removedIngredients: string[],
    notes: string,
    finalUnitPrice: number
  ) => {
    const itemUniqueId = `${product.id}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newItem: CartItem = {
      itemUniqueId,
      productId: product.id,
      name: product.name,
      basePrice: product.promoPrice || product.price,
      unitPrice: finalUnitPrice,
      quantity,
      image: product.image,
      selectedAddons,
      removedIngredients,
      notes,
      totalPrice: finalUnitPrice * quantity,
    };

    setCart((prev) => [...prev, newItem]);
    setToastMessage(`✓ ${product.name} adicionado ao carrinho!`);
  };

  // Quick Add (1 unit, without customization modal)
  const handleQuickAdd = (product: Product) => {
    const existingIndex = cart.findIndex(
      (item) => item.productId === product.id && item.selectedAddons.length === 0 && item.removedIngredients.length === 0 && !item.notes
    );

    const unitPrice = product.promoPrice || product.price;

    if (existingIndex > -1) {
      setCart((prev) => {
        const next = [...prev];
        next[existingIndex].quantity += 1;
        next[existingIndex].totalPrice = next[existingIndex].quantity * next[existingIndex].unitPrice;
        return next;
      });
    } else {
      const itemUniqueId = `${product.id}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newItem: CartItem = {
        itemUniqueId,
        productId: product.id,
        name: product.name,
        basePrice: unitPrice,
        unitPrice,
        quantity: 1,
        image: product.image,
        selectedAddons: [],
        removedIngredients: [],
        notes: '',
        totalPrice: unitPrice,
      };
      setCart((prev) => [...prev, newItem]);
    }

    setToastMessage(`✓ ${product.name} adicionado ao carrinho!`);
  };

  // Update item quantity in cart
  const handleUpdateQuantity = (uniqueId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.itemUniqueId === uniqueId) {
            const newQty = item.quantity + delta;
            if (newQty <= 0) return null;
            return {
              ...item,
              quantity: newQty,
              totalPrice: newQty * item.unitPrice,
            };
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null);
    });
  };

  // Remove single item from cart
  const handleRemoveItem = (uniqueId: string) => {
    setCart((prev) => prev.filter((item) => item.itemUniqueId !== uniqueId));
  };

  // Clear all cart
  const handleClearCart = () => {
    setCart([]);
    setCouponCode('');
    setDiscountAmount(0);
    setToastMessage('Carrinho esvaziado.');
  };

  // Apply Coupon
  const handleApplyCoupon = (code: string, discount: number) => {
    setCouponCode(code);
    setDiscountAmount(discount);
    return { success: true, message: 'Cupom aplicado!' };
  };

  const handleRemoveCoupon = () => {
    setCouponCode('');
    setDiscountAmount(0);
  };

  // Filtered Products for live search or specialized filter pills
  const filteredProducts = useMemo(() => {
    let list = products;

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query)
      );
    }

    if (selectedFilter === 'promo') {
      list = list.filter((p) => p.isPromo || !!p.promoPrice);
    } else if (selectedFilter === 'vegetarian') {
      list = list.filter((p) => p.isVegetarian);
    } else if (selectedFilter === 'popular') {
      list = list.filter((p) => p.isPopular);
    } else if (selectedFilter !== 'all') {
      list = list.filter((p) => p.category === selectedFilter);
    }

    return list;
  }, [searchQuery, selectedFilter]);

  // Product groups for Netflix rows
  const comboProducts = useMemo(() => products.filter((p) => p.category === 'combos'), []);
  const burgerProducts = useMemo(() => products.filter((p) => p.category === 'hamburgueres'), []);
  const pizzaProducts = useMemo(() => products.filter((p) => p.category === 'pizzas'), []);
  const salgadoProducts = useMemo(() => products.filter((p) => p.category === 'salgados'), []);
  const hotDogProducts = useMemo(() => products.filter((p) => p.category === 'hotdogs'), []);
  const lancheProducts = useMemo(() => products.filter((p) => p.category === 'lanches'), []);
  const porcaoProducts = useMemo(() => products.filter((p) => p.category === 'porcoes'), []);
  const bebidaProducts = useMemo(() => products.filter((p) => p.category === 'bebidas'), []);
  const sobremesaProducts = useMemo(() => products.filter((p) => p.category === 'sobremesas'), []);
  const popularProducts = useMemo(() => products.filter((p) => p.isPopular), []);
  const promoProducts = useMemo(() => products.filter((p) => p.isPromo || !!p.promoPrice), []);

  // Cross-sell & Upsell items for cart drawer (drink, fries, salgado or dessert)
  const upsellItems = useMemo(
    () => products.filter((p) => p.category === 'porcoes' || p.category === 'bebidas' || p.category === 'salgados' || p.category === 'sobremesas'),
    []
  );

  return (
    <div className="min-h-screen bg-[#0D0D0E] text-[#F3F4F6] flex flex-col selection:bg-[#E6392F] selection:text-white">
      {/* 1. Header / Navbar */}
      <Navbar
        config={config}
        cartCount={cartCount}
        cartTotal={cartSubtotal}
        onOpenCart={() => setIsCartOpen(true)}
        onSelectCategory={(cat) => {
          setSelectedFilter(cat as FilterType);
          const el = document.getElementById('cardapio-section');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      {/* 2. Hero Combos Animated Translucent Showcase */}
      {selectedFilter === 'all' && !searchQuery && (
        <HeroCombos
          combos={comboProducts}
          onSelectProduct={(p) => setSelectedProduct(p)}
          onQuickAdd={handleQuickAdd}
        />
      )}

      {/* 3. Netflix Category Filter & Live Search Bar */}
      <div id="cardapio-section">
        <CategoryFilterBar
          selectedFilter={selectedFilter}
          onSelectFilter={setSelectedFilter}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          totalProductsCount={filteredProducts.length}
        />
      </div>

      {/* 4. Menu Presentation: Filtered Grid vs. Netflix Rows */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-6">
        {/* Case A: Search or Specialized Filter Active */}
        {searchQuery || selectedFilter !== 'all' ? (
          <div className="py-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-black text-white">
                  {searchQuery
                    ? `Resultados para "${searchQuery}"`
                    : selectedFilter === 'promo'
                    ? '🔥 Promoções & Ofertas Especiais'
                    : selectedFilter === 'vegetarian'
                    ? '🌱 Opções Vegetarianas'
                    : selectedFilter === 'popular'
                    ? '⭐ Os Favoritos Mais Pedidos'
                    : selectedFilter === 'pizzas'
                    ? '🍕 Pizzas Artesanais & Forneadas'
                    : selectedFilter === 'salgados'
                    ? '🥟 Salgados Fritos & Assados Especiais'
                    : selectedFilter.toUpperCase()}
                </h2>
                <p className="text-xs text-zinc-400">
                  {filteredProducts.length} item(s) encontrado(s) no cardápio
                </p>
              </div>

              {(searchQuery || selectedFilter !== 'all') && (
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedFilter('all');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-300 transition-colors"
                >
                  Limpar Filtros
                </button>
              )}
            </div>

            {filteredProducts.length === 0 ? (
              <div className="p-12 text-center rounded-3xl bg-zinc-900/50 border border-white/5 space-y-3">
                <span className="text-4xl">🔍</span>
                <h3 className="text-lg font-bold text-white">Nenhum produto encontrado</h3>
                <p className="text-xs text-zinc-400 max-w-sm mx-auto">
                  Tente buscar por outro termo como "bacon", "smash", "hotdog", "refrigerante" ou limpe os filtros.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedFilter('all');
                  }}
                  className="px-4 py-2 rounded-xl bg-red-600 text-white font-bold text-xs"
                >
                  Ver Todo o Cardápio
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {filteredProducts.map((product) => {
                  const currentPrice = product.promoPrice || product.price;
                  return (
                    <div
                      key={product.id}
                      className="rounded-2xl bg-[#16161A] border border-white/10 overflow-hidden flex flex-col justify-between hover:border-red-500/50 transition-all shadow-lg"
                    >
                      <div
                        className="relative h-48 bg-zinc-900 overflow-hidden cursor-pointer group"
                        onClick={() => setSelectedProduct(product)}
                      >
                        <img
                          src={product.image}
                          alt={product.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80';
                          }}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-[#16161A] via-transparent to-black/20" />
                        
                        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 items-start">
                          {product.badge && (
                            <span className="px-2.5 py-0.5 rounded-md bg-red-600 text-white font-bold text-[10px] uppercase shadow">
                              {product.badge}
                            </span>
                          )}
                          {product.isVegetarian && (
                            <span className="px-2 py-0.5 rounded-md bg-emerald-700 text-white font-bold text-[10px] shadow">
                              🌱 VEGGIE
                            </span>
                          )}
                        </div>

                        {product.promoPrice && (
                          <span className="absolute top-2.5 right-2.5 px-2 py-0.5 rounded-md bg-amber-400 text-zinc-950 font-black text-[10px]">
                            OFERTA
                          </span>
                        )}

                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <span className="px-3 py-1.5 rounded-xl bg-white text-zinc-950 font-bold text-xs shadow-lg flex items-center gap-1">
                            <Eye className="w-3.5 h-3.5" /> Personalizar
                          </span>
                        </div>
                      </div>

                      <div className="p-4 flex-1 flex flex-col justify-between">
                        <div>
                          <h3
                            onClick={() => setSelectedProduct(product)}
                            className="font-bold text-white text-base hover:text-red-400 transition-colors cursor-pointer line-clamp-1 mb-1"
                          >
                            {product.name}
                          </h3>
                          <p className="text-zinc-400 text-xs line-clamp-2 leading-relaxed mb-3">
                            {product.description}
                          </p>
                        </div>

                        <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                          <div>
                            {product.promoPrice && (
                              <span className="text-[11px] text-zinc-500 line-through block -mb-1">
                                R$ {product.price.toFixed(2).replace('.', ',')}
                              </span>
                            )}
                            <span className="text-lg font-black text-[#FFC857]">
                              R$ {currentPrice.toFixed(2).replace('.', ',')}
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => setSelectedProduct(product)}
                              className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold"
                            >
                              Opções
                            </button>
                            <button
                              onClick={() => handleQuickAdd(product)}
                              className="p-2 rounded-xl bg-[#E6392F] hover:bg-red-600 text-white font-bold transition-all shadow-md shadow-red-950/40 active:scale-95"
                              title="Adicionar direto ao carrinho"
                            >
                              <Plus className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          /* Case B: Full Netflix-Style Horizontal Rows */
          <div className="space-y-6">
            {/* Row 1: Os Favoritos da Casa */}
            <NetflixRow
              title="Os Favoritos da Casa"
              subtitle="Os lanches e combos mais pedidos e elogiados pelos nossos clientes"
              icon="🔥"
              badgeText="TOP VENDAS"
              badgeColor="bg-amber-400/20 text-amber-300 border-amber-400/40"
              products={popularProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />

            {/* Row 2: Combos Completos */}
            <NetflixRow
              title="Combos Especiais & Destaques"
              subtitle="Hambúrguer ou lanche + batata quentinha + refrigerante gelado com super desconto"
              icon="🍟"
              badgeText="ECONOMIZE ATÉ R$ 15"
              badgeColor="bg-red-500/20 text-red-400 border-red-500/40"
              products={comboProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />

            {/* Row 3: Hambúrgueres Artesanais */}
            <NetflixRow
              title="Hambúrgueres Artesanais & Smash"
              subtitle="Pães brioche selados na manteiga e blends nobres feitos na brasa"
              icon="🍔"
              products={burgerProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />

            {/* Row 4: Pizzas Artesanais & Forneadas (Requested!) */}
            <NetflixRow
              title="Pizzas Artesanais Forneadas na Hora"
              subtitle="Massa artesanal de fermentação lenta com farto queijo derretido e bordas recheadas"
              icon="🍕"
              badgeText="FORNO A LENHA"
              badgeColor="bg-amber-400/20 text-amber-300 border-amber-400/40"
              products={pizzaProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />

            {/* Row 5: Salgados Fritos & Assados na Hora (Requested!) */}
            <NetflixRow
              title="Salgados Fritos & Assados Especiais"
              subtitle="Coxinhas com Catupiry, kibes recheados, pastéis estaladiços, esfirras e caixas para festa"
              icon="🥟"
              badgeText="SUPER CROCANTES"
              badgeColor="bg-red-500/20 text-red-400 border-red-500/40"
              products={salgadoProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />

            {/* Row 6: Hot Dogs Especiais & Prensados */}
            <NetflixRow
              title="Hot Dogs Especiais & Prensados"
              subtitle="Cachorros-quentes gourmet com purê cremoso, bacon crispy e prensados na chapa"
              icon="🌭"
              badgeText="NOVAS OPÇÕES"
              badgeColor="bg-amber-400/20 text-amber-300 border-amber-400/40"
              products={hotDogProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />

            {/* Row 5: Lanches Tradicionais (X-Tudo, X-Bacon, etc.) */}
            <NetflixRow
              title="Lanches Tradicionais de Lanchonete"
              subtitle="X-Tudo Supremo, X-Bacon, X-Egg e filé de frango com Catupiry original"
              icon="🥪"
              badgeText="CLÁSSICOS"
              products={lancheProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />

            {/* Row 6: Porções & Acompanhamentos */}
            <NetflixRow
              title="Porções & Acompanhamentos Crocantes"
              subtitle="Batatas rústicas com cheddar e bacon, batatas fritas palito e onion rings"
              icon="🍗"
              products={porcaoProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />

            {/* Row 7: Refrigerantes & Bebidas */}
            <NetflixRow
              title="Refrigerantes & Bebidas Geladas"
              subtitle="Lata 350ml, garrafas 2L, sucos naturais e água para refrescar o seu momento"
              icon="🥤"
              products={bebidaProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />

            {/* Row 8: Sobremesas & Shakes */}
            <NetflixRow
              title="Sobremesas & Shakes Artesanais"
              subtitle="Para fechar o seu pedido com chave de ouro: brownies com sorvete e milkshakes"
              icon="🍰"
              products={sobremesaProducts}
              onSelectProduct={setSelectedProduct}
              onQuickAdd={handleQuickAdd}
            />
          </div>
        )}
      </main>

      {/* 5. Testimonials Section */}
      <Testimonials />

      {/* 6. Footer */}
      <Footer config={config} />

      {/* 7. Product Customization Modal */}
      <ProductModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* 8. Cart Slide-Over Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        upsellProducts={upsellItems}
        onQuickAddUpsell={handleQuickAdd}
        config={config}
        couponCode={couponCode}
        discountAmount={discountAmount}
        onApplyCoupon={handleApplyCoupon}
        onRemoveCoupon={handleRemoveCoupon}
      />

      {/* 9. Checkout Modal & Automated WhatsApp message generator */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        config={config}
        discountAmount={discountAmount}
        couponCode={couponCode}
        onOrderCompleted={() => {
          setIsCheckoutOpen(false);
          setCart([]);
          setCouponCode('');
          setDiscountAmount(0);
          setToastMessage('🎉 Pedido enviado com sucesso para o WhatsApp!');
        }}
      />

      {/* 10. Floating WhatsApp Button */}
      <FloatingWhatsApp config={config} />

      {/* 12. Floating Mobile Cart Bottom Bar */}
      <MobileCartBar
        itemCount={cartCount}
        total={cartSubtotal}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* 13. Toast Notification */}
      <Toast
        message={toastMessage}
        onClose={() => setToastMessage('')}
        onOpenCart={() => setIsCartOpen(true)}
      />
    </div>
  );
}
