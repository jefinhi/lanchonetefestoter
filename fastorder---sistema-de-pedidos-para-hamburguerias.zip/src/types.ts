export interface Addon {
  id: string;
  name: string;
  price: number;
}

export interface Product {
  id: string;
  name: string;
  category: 'combos' | 'hamburgueres' | 'hotdogs' | 'lanches' | 'pizzas' | 'salgados' | 'porcoes' | 'bebidas' | 'sobremesas';
  description: string;
  price: number;
  promoPrice?: number;
  image: string;
  badge?: string;
  isVegetarian?: boolean;
  isPromo?: boolean;
  isPopular?: boolean;
  outOfStock?: boolean;
  availableAddons?: Addon[];
  removableIngredients?: string[];
}

export interface CartItem {
  itemUniqueId: string;
  productId: string;
  name: string;
  basePrice: number;
  unitPrice: number;
  quantity: number;
  image: string;
  selectedAddons: Addon[];
  removedIngredients: string[];
  notes?: string;
  totalPrice: number;
}

export interface RestaurantConfig {
  name: string;
  slogan: string;
  whatsapp: string;
  phone: string;
  address: string;
  neighborhood: string;
  city: string;
  deliveryFee: number;
  minimumOrder: number;
  isOpen: boolean;
  openingHoursText: string;
  estimatedTime: string;
  pixKey: string;
  instagram: string;
}

export type DeliveryType = 'delivery' | 'pickup';
export type PaymentMethod = 'pix' | 'money' | 'card_delivery' | 'card_pickup';

export interface OrderDetails {
  customerName: string;
  customerPhone: string;
  deliveryType: DeliveryType;
  address: {
    street: string;
    number: string;
    neighborhood: string;
    complement: string;
    city: string;
    reference: string;
  };
  paymentMethod: PaymentMethod;
  needChange: boolean;
  changeFor: string;
  notes: string;
  couponCode: string;
  discount: number;
}
