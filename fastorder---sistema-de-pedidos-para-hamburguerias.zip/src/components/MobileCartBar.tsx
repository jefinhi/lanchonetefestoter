import React from 'react';
import { ShoppingBag, ArrowRight } from 'lucide-react';

interface MobileCartBarProps {
  itemCount: number;
  total: number;
  onOpenCart: () => void;
}

export const MobileCartBar: React.FC<MobileCartBarProps> = ({
  itemCount,
  total,
  onOpenCart,
}) => {
  if (itemCount === 0) return null;

  return (
    <div className="fixed bottom-0 inset-x-0 z-40 sm:hidden p-3 bg-[#111113]/95 backdrop-blur-lg border-t border-white/10 shadow-2xl animate-in slide-in-from-bottom duration-200">
      <button
        id="btn-mobile-cart-bar"
        onClick={onOpenCart}
        className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-[#E6392F] to-[#c52c23] hover:from-[#f3453b] hover:to-[#d63229] text-white font-extrabold text-sm shadow-xl shadow-red-950/60 flex items-center justify-between active:scale-98 transition-all"
      >
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-black/30">
            <ShoppingBag className="w-4 h-4" />
          </div>
          <span>
            {itemCount} {itemCount === 1 ? 'item' : 'itens'} no carrinho
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[#FFC857] font-black text-base">
            R$ {total.toFixed(2).replace('.', ',')}
          </span>
          <ArrowRight className="w-4 h-4" />
        </div>
      </button>
    </div>
  );
};
