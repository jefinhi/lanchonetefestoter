import React from 'react';
import { MessageCircle } from 'lucide-react';
import { RestaurantConfig } from '../types';

interface FloatingWhatsAppProps {
  config: RestaurantConfig;
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({ config }) => {
  const cleanWhatsapp = config.whatsapp.replace(/\D/g, '');
  const message = encodeURIComponent(`Olá! Gostaria de fazer um pedido no ${config.name}.`);
  const waUrl = `https://wa.me/${cleanWhatsapp}?text=${message}`;

  return (
    <a
      id="btn-floating-whatsapp"
      href={waUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-20 sm:bottom-5 right-3.5 sm:right-5 z-40 flex items-center justify-center w-10 h-10 sm:w-11 sm:h-11 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white shadow-lg shadow-green-950/50 hover:scale-110 active:scale-95 transition-all group"
      title="Falar no WhatsApp"
      aria-label="Falar no WhatsApp"
    >
      <MessageCircle className="w-5 h-5 fill-white text-transparent group-hover:rotate-12 transition-transform" />
      <span className="sr-only">WhatsApp</span>
    </a>
  );
};
