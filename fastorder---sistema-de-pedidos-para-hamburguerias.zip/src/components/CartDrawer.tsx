import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag, Sparkles, AlertCircle } from 'lucide-react';
import { CartItem, Product, RestaurantConfig } from '../types';
import { validCoupons } from '../data/products';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (uniqueId: string, delta: number) => void;
  onRemoveItem: (uniqueId: string) => void;
  onClearCart: () => void;
  onProceedToCheckout: () => void;
  upsellProducts: Product[];
  onQuickAddUpsell: (product: Product) => void;
  config: RestaurantConfig;
  couponCode: string;
  discountAmount: number;
  onApplyCoupon: (code: string, discount: number) => { success: boolean; message: string };
  onRemoveCoupon: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onProceedToCheckout,
  upsellProducts,
  onQuickAddUpsell,
  config,
  couponCode,
  discountAmount,
  onApplyCoupon,
  onRemoveCoupon,
}) => {
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  if (!isOpen) return null;

  const subtotal = items.reduce((acc, item) => acc + item.totalPrice, 0);
  const deliveryFee = config.deliveryFee;
  const finalTotal = Math.max(0, subtotal + deliveryFee - discountAmount);
  const isMinimumReached = subtotal >= config.minimumOrder;
  const missingForMinimum = config.minimumOrder - subtotal;

  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    setCouponSuccess('');
    const code = couponInput.trim().toUpperCase();
    if (!code) return;

    const couponData = validCoupons[code];
    if (couponData) {
      let discount = 0;
      if (couponData.discountPercent) {
        discount = (subtotal * couponData.discountPercent) / 100;
      } else if (couponData.discountFixed) {
        discount = couponData.discountFixed;
      }
      const res = onApplyCoupon(code, discount);
      if (res.success) {
        setCouponSuccess(`Cupom ${code} aplicado! ${couponData.description}`);
        setCouponInput('');
      } else {
        setCouponError(res.message);
      }
    } else {
      setCouponError('Cupom inválido. Tente BEMVINDO10 ou BURGER5');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="absolute inset-y-0 right-0 max-w-full flex pl-6 sm:pl-10">
        <div className="w-screen max-w-md bg-[#161619] border-l border-white/10 shadow-2xl flex flex-col">
          
          {/* Drawer Header */}
          <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-[#121215]">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-red-600/20 text-red-500">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-black text-white">Seu Pedido</h2>
                <p className="text-xs text-zinc-400">
                  {items.length} {items.length === 1 ? 'item' : 'itens'} adicionado(s)
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {items.length > 0 && (
                <button
                  onClick={() => setShowClearConfirm(true)}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-zinc-400 hover:text-red-400 hover:bg-white/5 transition-colors"
                  title="Esvaziar todos os itens do carrinho"
                >
                  Esvaziar
                </button>
              )}
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
                aria-label="Fechar carrinho"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Confirm Clear Modal Dialog */}
          {showClearConfirm && (
            <div className="p-4 bg-red-950/40 border-b border-red-500/30 flex flex-col gap-2 animate-in fade-in duration-150">
              <p className="text-xs font-bold text-red-200">
                Tem certeza que deseja remover todos os produtos do carrinho?
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    onClearCart();
                    setShowClearConfirm(false);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-xs"
                >
                  Sim, Esvaziar
                </button>
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-semibold text-xs"
                >
                  Cancelar
                </button>
              </div>
            </div>
          )}

          {/* Drawer Body */}
          <div className="flex-1 overflow-y-auto custom-scrollbar p-4 sm:p-5 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
                <div className="w-20 h-20 rounded-3xl bg-zinc-800/60 border border-white/5 flex items-center justify-center text-4xl shadow-inner">
                  🛒
                </div>
                <div>
                  <h3 className="text-base font-bold text-white mb-1">Seu carrinho está vazio</h3>
                  <p className="text-xs text-zinc-400 max-w-xs">
                    Que tal escolher um delicioso hambúrguer artesanal ou combo para começar?
                  </p>
                </div>
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#E6392F] to-[#c52c23] text-white font-bold text-xs shadow-lg shadow-red-950/50 hover:scale-105 transition-transform"
                >
                  VER CARDÁPIO
                </button>
              </div>
            ) : (
              <>
                {/* List of Cart Items */}
                <div className="space-y-3">
                  {items.map((item) => (
                    <div
                      key={item.itemUniqueId}
                      className="p-3.5 rounded-2xl bg-zinc-900/80 border border-white/5 flex gap-3 items-start"
                    >
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 rounded-xl object-cover flex-shrink-0"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=200&q=80";
                        }}
                      />

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-1">
                          <h4 className="font-bold text-sm text-white truncate">{item.name}</h4>
                          <button
                            onClick={() => onRemoveItem(item.itemUniqueId)}
                            className="text-zinc-500 hover:text-red-400 p-1 transition-colors"
                            title="Remover produto"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {/* Selected Addons & Removals text */}
                        {item.selectedAddons.length > 0 && (
                          <p className="text-[11px] text-amber-300/90 mt-0.5 line-clamp-1">
                            + {item.selectedAddons.map((a) => a.name).join(', ')}
                          </p>
                        )}
                        {item.removedIngredients.length > 0 && (
                          <p className="text-[11px] text-zinc-400 line-through mt-0.5 line-clamp-1">
                            {item.removedIngredients.join(', ')}
                          </p>
                        )}
                        {item.notes && (
                          <p className="text-[11px] text-zinc-400 italic mt-0.5 line-clamp-1">
                            Obs: "{item.notes}"
                          </p>
                        )}

                        <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5">
                          <span className="font-bold text-sm text-[#FFC857]">
                            R$ {item.totalPrice.toFixed(2).replace('.', ',')}
                          </span>

                          <div className="flex items-center gap-2 bg-zinc-800 rounded-lg p-1">
                            <button
                              onClick={() => onUpdateQuantity(item.itemUniqueId, -1)}
                              className="p-1 rounded text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-xs font-bold text-white px-1">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => onUpdateQuantity(item.itemUniqueId, 1)}
                              className="p-1 rounded text-zinc-300 hover:text-white hover:bg-zinc-700 transition-colors"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Upsell / Cross-Sell (Que tal completar seu pedido?) */}
                {upsellProducts.length > 0 && (
                  <div className="pt-2">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                        Que tal completar seu pedido?
                      </span>
                    </div>

                    <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                      {upsellProducts.slice(0, 4).map((p) => (
                        <div
                          key={p.id}
                          className="flex-none w-44 p-2.5 rounded-xl bg-zinc-900/60 border border-white/5 flex flex-col justify-between"
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <img
                              src={p.image}
                              alt={p.name}
                              className="w-10 h-10 rounded-lg object-cover"
                            />
                            <div className="min-w-0 flex-1">
                              <p className="text-xs font-bold text-white truncate">{p.name}</p>
                              <p className="text-[11px] font-bold text-[#FFC857]">
                                R$ {(p.promoPrice || p.price).toFixed(2).replace('.', ',')}
                              </p>
                            </div>
                          </div>
                          <button
                            onClick={() => onQuickAddUpsell(p)}
                            className="w-full py-1 rounded-lg bg-zinc-800 hover:bg-red-600 text-white font-bold text-[11px] transition-colors flex items-center justify-center gap-1"
                          >
                            <Plus className="w-3 h-3" /> Adicionar
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Coupon Input */}
                <div className="pt-3 border-t border-white/10">
                  <form onSubmit={handleCouponSubmit} className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-zinc-400" />
                      <input
                        type="text"
                        value={couponInput}
                        onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                        placeholder="Cupom: BEMVINDO10"
                        className="w-full pl-9 pr-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-xs text-white placeholder-zinc-500 uppercase tracking-wider focus:outline-none focus:ring-1 focus:ring-red-500"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs transition-colors"
                    >
                      APLICAR
                    </button>
                  </form>

                  {couponSuccess && (
                    <p className="text-[11px] text-emerald-400 font-medium mt-1.5 flex items-center justify-between">
                      <span>✓ {couponSuccess}</span>
                      <button onClick={onRemoveCoupon} className="text-zinc-500 hover:text-red-400 ml-2">Remover</button>
                    </p>
                  )}
                  {couponError && (
                    <p className="text-[11px] text-red-400 font-medium mt-1.5">
                      ✕ {couponError}
                    </p>
                  )}
                  {couponCode && !couponSuccess && (
                    <div className="flex items-center justify-between text-[11px] text-emerald-400 font-semibold mt-1">
                      <span>Cupom {couponCode} ativado (-R$ {discountAmount.toFixed(2).replace('.', ',')})</span>
                      <button onClick={onRemoveCoupon} className="text-zinc-500 hover:text-red-400">Remover</button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Drawer Footer: Order Summary & Checkout CTA */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 bg-[#121215] border-t border-white/10 space-y-3">
              {/* Financial Breakdown */}
              <div className="space-y-1.5 text-xs text-zinc-300">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-semibold text-white">
                    R$ {subtotal.toFixed(2).replace('.', ',')}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span>Taxa de Entrega estimada</span>
                  <span className="font-semibold text-white">
                    R$ {deliveryFee.toFixed(2).replace('.', ',')}
                  </span>
                </div>

                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-400 font-semibold">
                    <span>Desconto</span>
                    <span>- R$ {discountAmount.toFixed(2).replace('.', ',')}</span>
                  </div>
                )}

                <div className="pt-2 border-t border-white/10 flex justify-between items-baseline">
                  <span className="text-sm font-bold text-white">Total Final</span>
                  <span className="text-xl font-black text-[#FFC857]">
                    R$ {finalTotal.toFixed(2).replace('.', ',')}
                  </span>
                </div>
              </div>

              {/* Minimum Order Warning */}
              {!isMinimumReached && (
                <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>
                    Adicione mais <strong>R$ {missingForMinimum.toFixed(2).replace('.', ',')}</strong> para atingir o pedido mínimo.
                  </span>
                </div>
              )}

              {/* Checkout Button */}
              <button
                id="btn-proceed-checkout"
                onClick={onProceedToCheckout}
                disabled={!isMinimumReached}
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#E6392F] to-[#c52c23] hover:from-[#f3453b] hover:to-[#d63229] disabled:opacity-40 disabled:pointer-events-none text-white font-extrabold text-sm sm:text-base shadow-xl shadow-red-950/60 transition-all flex items-center justify-center gap-2 active:scale-95"
              >
                <span>FINALIZAR PEDIDO</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
