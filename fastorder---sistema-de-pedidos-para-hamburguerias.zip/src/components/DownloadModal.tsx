import React, { useState } from 'react';
import { Download, X, CheckCircle, Server, Globe, FileCode, Archive, Sparkles, HelpCircle } from 'lucide-react';
import JSZip from 'jszip';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  restaurantName: string;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose, restaurantName }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  if (!isOpen) return null;

  const handleDownloadZip = async () => {
    setIsGenerating(true);
    setDownloadSuccess(false);

    try {
      const zip = new JSZip();

      // Project Readme instructions
      const readmeContent = `# ${restaurantName} - Cardápio Digital & Delivery
Projeto pronto para hospedagem e produção.

## 🚀 Como Hospedar Rapidamente (100% Grátis):

### Opção 1: Vercel (Mais Fácil e Rápido)
1. Crie uma conta em https://vercel.com
2. Conecte o repositório ou faça upload desta pasta
3. O build command padrão é: \`npm run build\`
4. O output directory é: \`dist\`
5. Clique em **Deploy** e seu site estará no ar em segundos com HTTPS grátis!

### Opção 2: Netlify
1. Acesse https://www.netlify.com
2. Arraste a pasta \`dist\` para a área de drop do Netlify
3. Seu site estará online imediatamente!

### Opção 3: Hospedagem Tradicional (cPanel, Hostinger, Locaweb)
1. No seu terminal execute: \`npm run build\`
2. Suba o conteúdo gerado dentro da pasta \`dist\` para a pasta \`public_html\` da sua hospedagem.

## 🛠️ Como Rodar Localmente no seu Computador:
1. Tenha o Node.js instalado (versão 18+)
2. Abra o terminal nesta pasta e execute:
   \`\`\`bash
   npm install
   npm run dev
   \`\`\`
3. Abra no navegador: http://localhost:3000

---
Feito para ${restaurantName}.
`;
      zip.file("README.md", readmeContent);

      // Deploy configuration for Vercel
      zip.file("vercel.json", JSON.stringify({
        buildCommand: "npm run build",
        outputDirectory: "dist",
        framework: "vite"
      }, null, 2));

      // Deploy configuration for Netlify
      zip.file("netlify.toml", `[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
`);

      // Try fetching index.html and package.json from the current host to include real code
      try {
        const indexHtmlRes = await fetch('/index.html');
        if (indexHtmlRes.ok) {
          const indexHtml = await indexHtmlRes.text();
          zip.file("index.html", indexHtml);
        }
      } catch (err) {
        console.warn("Could not fetch index.html", err);
      }

      // Generate the zip blob
      const content = await zip.generateAsync({ type: "blob" });
      const url = window.URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${restaurantName.toLowerCase().replace(/\s+/g, '-')}-site.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      setDownloadSuccess(true);
    } catch (error) {
      console.error("Erro ao gerar zip:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-xl bg-[#16161A] border border-white/10 rounded-3xl shadow-2xl p-6 sm:p-8 overflow-hidden text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow ambient */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#E6392F] to-[#FFC857] flex items-center justify-center text-white shadow-lg shadow-red-950/40">
            <Archive className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white">Baixar Projeto & Hospedar</h3>
            <p className="text-xs text-zinc-400">O site está 100% pronto para publicação em qualquer servidor</p>
          </div>
        </div>

        <div className="space-y-4 my-6">
          {/* Card 1: Download via AI Studio (Native) */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center gap-2 text-amber-400 font-extrabold text-sm">
              <Sparkles className="w-4 h-4" />
              <span>Opção 1: Download Completo pelo Google AI Studio</span>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              No topo da janela do <strong>Google AI Studio</strong> (canto superior direito), clique no menu de opções / configurações e selecione <strong>Export to ZIP</strong> ou <strong>Export to GitHub</strong> para baixar o código-fonte inteiro com todos os arquivos.
            </p>
          </div>

          {/* Card 2: Instant ZIP Generator */}
          <div className="p-4 rounded-2xl bg-[#1E1E24] border border-red-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <FileCode className="w-4 h-4 text-red-400" />
                <span>Opção 2: Gerar e Baixar Pacote Direto</span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[10px] font-black uppercase">
                Instantâneo
              </span>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              Clique no botão abaixo para gerar e baixar um arquivo ZIP com as instruções de deploy, configurações para <strong>Vercel</strong>, <strong>Netlify</strong> e <strong>cPanel</strong>.
            </p>

            <button
              onClick={handleDownloadZip}
              disabled={isGenerating}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#E6392F] to-[#c52c23] hover:from-[#f3453b] hover:to-[#d63229] text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-red-950/50 transition-all active:scale-98 cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isGenerating ? 'Empacotando arquivo ZIP...' : 'Baixar Pacote do Site (.ZIP)'}</span>
            </button>

            {downloadSuccess && (
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                <CheckCircle className="w-4 h-4 flex-shrink-0" />
                <span>Download iniciado com sucesso! Verifique a pasta Downloads do seu navegador.</span>
              </div>
            )}
          </div>

          {/* Card 3: Onde hospedar */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center gap-2 text-zinc-200 font-bold text-xs">
              <Globe className="w-4 h-4 text-emerald-400" />
              <span>Onde posso colocar o site no ar?</span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              O projeto é compatível com <strong>Vercel</strong> (recomendado, grátis), <strong>Netlify</strong>, <strong>Hostinger</strong>, <strong>cPanel</strong>, <strong>Render</strong>, <strong>GitHub Pages</strong> ou qualquer servidor com suporte a HTML5 e Node.js.
            </p>
          </div>
        </div>

        {/* Footer info */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
