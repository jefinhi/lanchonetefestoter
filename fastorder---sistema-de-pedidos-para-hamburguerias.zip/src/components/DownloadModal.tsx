import React, { useState } from 'react';
import { Download, X, CheckCircle, Globe, FileCode, Archive, Sparkles, Check, Laptop } from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  restaurantName: string;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose, restaurantName }) => {
  const [downloadSuccessHtml, setDownloadSuccessHtml] = useState(false);
  const [downloadSuccessZip, setDownloadSuccessZip] = useState(false);

  if (!isOpen) return null;

  const handleDownloadHtml = () => {
    try {
      const link = document.createElement('a');
      link.href = '/cardapio-fastorder.html';
      link.download = 'index.html';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setDownloadSuccessHtml(true);
      setTimeout(() => setDownloadSuccessHtml(false), 4000);
    } catch (err) {
      console.error('Erro ao baixar HTML:', err);
    }
  };

  const handleDownloadZip = () => {
    try {
      const link = document.createElement('a');
      link.href = '/fastorder-site-completo.zip';
      link.download = `${restaurantName.toLowerCase().replace(/\s+/g, '-')}-completo.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setDownloadSuccessZip(true);
      setTimeout(() => setDownloadSuccessZip(false), 4000);
    } catch (err) {
      console.error('Erro ao baixar ZIP:', err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-xl bg-[#16161A] border border-white/10 rounded-3xl shadow-2xl p-6 sm:p-8 overflow-hidden text-left"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Glow ambient */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#E6392F] to-[#FFC857] flex items-center justify-center text-white shadow-lg shadow-red-950/40">
            <Archive className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white">Baixar Site Pronto</h3>
            <p className="text-xs text-zinc-400">Sem erros de código: basta baixar e dar 2 cliques para abrir no seu computador</p>
          </div>
        </div>

        <div className="space-y-4 my-6">
          {/* Card 1: Single-file HTML (Instant Double-Click Open) */}
          <div className="p-4 rounded-2xl bg-gradient-to-b from-amber-500/10 to-transparent border border-amber-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <FileCode className="w-5 h-5 text-amber-400" />
                <span className="text-amber-300">Opção 1: Arquivo HTML Pronto (Recomendado)</span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 text-[10px] font-black uppercase tracking-wider">
                Abrir com 2 Cliques
              </span>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              Arquivo único 100% autônomo com todo o código JavaScript, estilos e imagens embutidos. <strong>Não precisa de servidor nem de instalar nada</strong>: após baixar, basta dar <strong>2 cliques no arquivo</strong> e ele abre perfeitamente em qualquer navegador (Chrome, Edge, Safari, Firefox).
            </p>

            <button
              onClick={handleDownloadHtml}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-zinc-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-950/40 transition-all active:scale-98 cursor-pointer"
            >
              <Download className="w-4 h-4 text-zinc-950" />
              <span>Baixar Arquivo HTML (cardapio-fastorder.html)</span>
            </button>

            {downloadSuccessHtml && (
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                <CheckCircle className="w-4 h-4 flex-shrink-0" />
                <span>Download do HTML iniciado! Verifique a pasta Downloads e dê 2 cliques no arquivo para abrir.</span>
              </div>
            )}
          </div>

          {/* Card 2: Full ZIP Package */}
          <div className="p-4 rounded-2xl bg-[#1E1E24] border border-red-500/30 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <Archive className="w-5 h-5 text-red-400" />
                <span>Opção 2: Pacote Completo do Site (.ZIP)</span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-red-500/20 text-red-400 text-[10px] font-black uppercase tracking-wider">
                Para Hospedar
              </span>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              Pacote ZIP completo contendo os arquivos prontos de produção, arquivos de configuração para <strong>Vercel</strong> e <strong>Netlify</strong>, e atalhos rápidos para Windows (<code>.bat</code>) e Mac/Linux (<code>.sh</code>).
            </p>

            <button
              onClick={handleDownloadZip}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#E6392F] to-[#c52c23] hover:from-[#f3453b] hover:to-[#d63229] text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-red-950/50 transition-all active:scale-98 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Baixar Pacote Completo (.ZIP)</span>
            </button>

            {downloadSuccessZip && (
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-semibold">
                <CheckCircle className="w-4 h-4 flex-shrink-0" />
                <span>Download do ZIP iniciado! Extraia a pasta e clique no arquivo 'abrir-direto.html' para abrir.</span>
              </div>
            )}
          </div>

          {/* Card 3: Como abrir no computador */}
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center gap-2 text-zinc-200 font-bold text-xs">
              <Laptop className="w-4 h-4 text-emerald-400" />
              <span>Instruções Rápidas:</span>
            </div>
            <ul className="text-xs text-zinc-300 space-y-1 list-disc list-inside">
              <li>Para abrir no PC/Celular: basta dar 2 cliques no arquivo <strong>.html</strong> baixado.</li>
              <li>Para hospedar online grátis: suba a pasta descompactada no <strong>Vercel</strong> ou <strong>Netlify</strong>.</li>
            </ul>
          </div>
        </div>

        {/* Footer info */}
        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
