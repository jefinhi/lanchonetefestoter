import React from 'react';
import { ShoppingBag, Clock, Sparkles, MapPin } from 'lucide-react';
import { RestaurantConfig } from '../types';

interface NavbarProps {
  config: RestaurantConfig;
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  onSelectCategory: (cat: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  config,
  cartCount,
  cartTotal,
  onOpenCart,
  onSelectCategory,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#111113]/95 backdrop-blur-md border-b border-white/10 transition-all duration-200">
      {/* Top micro-bar: Opening Status & Delivery info */}
      <div className="bg-[#18181B] text-xs text-zinc-400 py-1.5 px-4 border-b border-white/5">
        <div className="max-w-7xl mx-auto flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 font-medium text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              {config.isOpen ? "Estamos Abertos" : "Fechado no momento"}
            </span>
            <span className="text-zinc-600 hidden sm:inline">•</span>
            <span className="hidden sm:inline-flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-zinc-400" />
              Tempo estimado: <strong className="text-zinc-200">{config.estimatedTime}</strong>
            </span>
            <span className="text-zinc-600 hidden md:inline">•</span>
            <span className="hidden md:inline-flex items-center gap-1 text-zinc-400">
              <MapPin className="w-3.5 h-3.5 text-zinc-500" />
              {config.address}, {config.neighborhood}
            </span>
          </div>

          <div className="flex items-center gap-3 ml-auto">
            <span className="text-amber-400 text-xs font-semibold flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> Pedido mínimo: R$ {config.minimumOrder.toFixed(2).replace('.', ',')}
            </span>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Brand / Logo */}
        <div className="flex items-center gap-3">
          <a href="#inicio" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#E6392F] to-[#FFC857] flex items-center justify-center shadow-lg shadow-red-950/40 text-xl font-black text-white group-hover:scale-105 transition-transform">
              🍔
            </div>
            <div>
              <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white flex items-center gap-1.5">
                {config.name}
              </span>
              <p className="text-[11px] text-zinc-400 -mt-1 hidden sm:block">
                Cardápio Digital & Delivery Rápido
              </p>
            </div>
          </a>
        </div>

        {/* Quick Nav Anchors */}
        <nav className="hidden lg:flex items-center gap-1">
          <button 
            onClick={() => onSelectCategory('all')} 
            className="px-2.5 py-1.5 text-xs font-semibold text-zinc-300 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          >
            Cardápio
          </button>
          <button 
            onClick={() => onSelectCategory('combos')} 
            className="px-2.5 py-1.5 text-xs font-semibold text-zinc-300 hover:text-white rounded-lg hover:bg-white/5 transition-colors flex items-center gap-1.5"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            Combos
          </button>
          <button 
            onClick={() => onSelectCategory('pizzas')} 
            className="px-2.5 py-1.5 text-xs font-semibold text-zinc-300 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          >
            🍕 Pizzas
          </button>
          <button 
            onClick={() => onSelectCategory('salgados')} 
            className="px-2.5 py-1.5 text-xs font-semibold text-zinc-300 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          >
            🥟 Salgados
          </button>
          <button 
            onClick={() => onSelectCategory('promo')} 
            className="px-2.5 py-1.5 text-xs font-semibold text-red-400 hover:text-red-300 rounded-lg hover:bg-red-950/20 transition-colors"
          >
            🔥 Promoções
          </button>
          <button 
            onClick={() => onSelectCategory('vegetarian')} 
            className="px-2.5 py-1.5 text-xs font-semibold text-emerald-400 hover:text-emerald-300 rounded-lg hover:bg-emerald-950/20 transition-colors"
          >
            🌱 Veggie
          </button>
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Cart Button */}
          <button
            id="btn-open-cart-header"
            onClick={onOpenCart}
            className="relative flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#E6392F] to-[#c52c23] hover:from-[#f3453b] hover:to-[#d63229] text-white font-semibold text-sm shadow-lg shadow-red-900/30 active:scale-95 transition-all"
          >
            <ShoppingBag className="w-5 h-5" />
            <span className="hidden md:inline">Carrinho</span>
            {cartCount > 0 ? (
              <span className="flex items-center gap-1 bg-black/40 text-amber-300 px-2 py-0.5 rounded-lg text-xs font-bold">
                <span>{cartCount}</span>
                <span className="text-zinc-400">•</span>
                <span>R$ {cartTotal.toFixed(2).replace('.', ',')}</span>
              </span>
            ) : (
              <span className="bg-black/30 text-zinc-300 px-1.5 py-0.5 rounded-md text-xs">
                0
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
