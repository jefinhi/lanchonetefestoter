import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, ChevronLeft, ChevronRight, Flame, Plus, Play, Pause, RefreshCw, Zap } from 'lucide-react';
import { Product } from '../types';

interface HeroCombosProps {
  combos: Product[];
  onSelectProduct: (product: Product) => void;
  onQuickAdd: (product: Product) => void;
}

const LOOP_INTERVAL_MS = 3600; // 3.6 seconds per combo

export const HeroCombos: React.FC<HeroCombosProps> = ({
  combos,
  onSelectProduct,
  onQuickAdd,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Infinite looping timer that never gets permanently killed
  useEffect(() => {
    if (combos.length === 0) return;

    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    if (!isPaused) {
      timerRef.current = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % combos.length);
      }, LOOP_INTERVAL_MS);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [combos.length, currentIndex, isPaused]);

  if (combos.length === 0) return null;

  const activeCombo = combos[currentIndex];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + combos.length) % combos.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % combos.length);
  };

  const handleSelectThumbnail = (index: number) => {
    setCurrentIndex(index);
  };

  return (
    <section 
      id="inicio"
      className="relative overflow-hidden pt-6 pb-10 bg-gradient-to-b from-[#111113] via-[#141417] to-[#0D0D0E]"
    >
      {/* Background Animated Ambient Lights */}
      <div className="absolute top-1/4 left-10 w-96 h-96 bg-red-600/20 rounded-full blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Section Headline with Infinite Loop Attention Badge */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-5 gap-3">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/15 border border-red-500/40 text-red-400 text-xs font-black tracking-wide uppercase shadow-sm">
                <Flame className="w-3.5 h-3.5 fill-red-400 animate-bounce" />
                Destaques em Alta & Promoções
              </div>

              {/* Looping Infinito Badge */}
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-400/15 border border-amber-400/40 text-amber-300 text-[11px] font-bold">
                <RefreshCw className={`w-3 h-3 ${!isPaused ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
                <span>Looping Infinito {isPaused ? '(Pausado)' : 'Ativo'}</span>
              </div>
            </div>

            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white leading-tight">
              Seu Lanche Favorito, <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFC857] via-[#E6392F] to-[#FF8A65]">
                Do Jeito Que Você Gosta.
              </span>
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <p className="text-xs sm:text-sm text-zinc-400 max-w-sm">
              Combos com batata quentinha e refrigerante gelado trocando em looping na sua tela.
            </p>
          </div>
        </div>

        {/* Moving Translucent Showcase Card */}
        <div className="relative rounded-3xl p-1 bg-gradient-to-r from-red-500/30 via-amber-500/30 to-red-500/30 shadow-2xl backdrop-blur-xl">
          <div className="relative rounded-[22px] bg-[#141418]/90 backdrop-blur-2xl border border-white/10 overflow-hidden min-h-[420px] md:min-h-[440px] flex flex-col justify-between">
            
            {/* Top Auto-Play Looping Progress Bar */}
            <div className="w-full bg-white/5 h-1.5 overflow-hidden">
              <div
                key={currentIndex}
                className={`h-full bg-gradient-to-r from-red-600 via-amber-400 to-red-500 ${
                  !isPaused ? 'animate-[hero-progress_3600ms_linear]' : 'w-full'
                }`}
                style={{
                  animationDuration: `${LOOP_INTERVAL_MS}ms`,
                }}
              />
            </div>

            {/* Background Image with Dynamic Translucency */}
            <div 
              className="absolute inset-0 bg-cover bg-center opacity-15 scale-105 transition-all duration-1000 blur-sm pointer-events-none"
              style={{ backgroundImage: `url(${activeCombo.image})` }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#141418] via-[#141418]/80 to-transparent pointer-events-none" />

            {/* Content Slide Container */}
            <div 
              key={activeCombo.id}
              className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center p-6 sm:p-10 animate-in fade-in zoom-in-95 duration-500"
            >
              {/* Left Column: Combo Details */}
              <div className="lg:col-span-7 flex flex-col items-start text-left">
                {/* Badge tags */}
                <div className="flex flex-wrap items-center gap-2 mb-3">
                  <span className="px-3 py-1 rounded-full bg-[#E6392F] text-white font-black text-xs shadow-lg shadow-red-950/60 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    {activeCombo.badge || 'COMBO ESPECIAL'}
                  </span>

                  {activeCombo.promoPrice && (
                    <span className="px-3 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 font-extrabold text-xs flex items-center gap-1">
                      <Zap className="w-3 h-3 text-amber-300 fill-amber-300" />
                      Economize R$ {(activeCombo.price - activeCombo.promoPrice).toFixed(2).replace('.', ',')}
                    </span>
                  )}

                  <span className="px-2.5 py-1 rounded-full bg-white/10 text-zinc-300 text-xs font-semibold">
                    Combo {currentIndex + 1} de {combos.length}
                  </span>
                </div>

                {/* Combo Title */}
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight mb-2.5 leading-tight">
                  {activeCombo.name}
                </h2>

                {/* Combo Description */}
                <p className="text-zinc-300 text-xs sm:text-sm leading-relaxed line-clamp-3 mb-5 max-w-2xl">
                  {activeCombo.description}
                </p>

                {/* Price Display */}
                <div className="flex items-baseline gap-3 mb-5">
                  <div className="flex flex-col">
                    <span className="text-[11px] text-zinc-400 font-semibold uppercase tracking-wider">
                      Valor do Combo Completo:
                    </span>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl sm:text-4xl font-black text-[#FFC857]">
                        R$ {(activeCombo.promoPrice || activeCombo.price).toFixed(2).replace('.', ',')}
                      </span>
                      {activeCombo.promoPrice && (
                        <span className="text-sm sm:text-base text-zinc-500 line-through">
                          R$ {activeCombo.price.toFixed(2).replace('.', ',')}
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                  <button
                    id={`btn-order-hero-${activeCombo.id}`}
                    onClick={() => onSelectProduct(activeCombo)}
                    className="flex-1 sm:flex-none px-6 py-3.5 rounded-2xl bg-gradient-to-r from-[#E6392F] to-[#c52c23] hover:from-[#f3453b] hover:to-[#d63229] text-white font-black text-xs sm:text-sm shadow-xl shadow-red-950/60 hover:shadow-red-900/80 transition-all flex items-center justify-center gap-2 group active:scale-95 cursor-pointer"
                  >
                    <span>PEDIR ESTE COMBO</span>
                    <span className="text-base group-hover:translate-x-1 transition-transform">🍔</span>
                  </button>

                  <button
                    id={`btn-quick-add-hero-${activeCombo.id}`}
                    onClick={() => onQuickAdd(activeCombo)}
                    className="px-4 py-3.5 rounded-2xl bg-white/10 hover:bg-white/15 text-white font-bold text-xs sm:text-sm border border-white/15 backdrop-blur-md transition-all flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
                    title="Adicionar direto ao carrinho"
                  >
                    <Plus className="w-4 h-4 text-amber-400" />
                    <span>Adicionar Rápido</span>
                  </button>
                </div>
              </div>

              {/* Right Column: Hero Translucent Floating Image Showcase with Glow */}
              <div className="lg:col-span-5 relative flex items-center justify-center">
                {/* Glowing ring animation */}
                <div className="absolute inset-0 m-auto w-64 h-64 sm:w-80 sm:h-80 rounded-full bg-gradient-to-tr from-red-600/40 via-amber-500/30 to-transparent blur-3xl animate-pulse pointer-events-none" />

                <div 
                  className="relative group cursor-pointer animate-float"
                  onClick={() => onSelectProduct(activeCombo)}
                  title="Clique para personalizar este combo"
                >
                  {/* Glassmorphism Frame */}
                  <div className="relative rounded-2xl overflow-hidden border border-white/25 shadow-2xl bg-black/50 backdrop-blur-md p-2 hover:border-red-500/60 transition-all">
                    <img
                      src={activeCombo.image}
                      alt={activeCombo.name}
                      className="w-full h-56 sm:h-72 object-cover rounded-xl transform transition-transform duration-700 group-hover:scale-105"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80";
                      }}
                    />
                    {/* Hover hint */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-xl backdrop-blur-xs">
                      <span className="px-4 py-2 rounded-xl bg-white text-zinc-950 font-black text-xs shadow-xl flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                        Clique para Personalizar
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Controls Bar: Arrows, Thumbnails & Pause/Play */}
            <div className="px-4 sm:px-6 py-3 bg-black/60 backdrop-blur-md border-t border-white/10 flex items-center justify-between gap-3">
              {/* Navigation Controls */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handlePrev}
                  className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/10 transition-all active:scale-95"
                  aria-label="Combo anterior"
                  title="Combo anterior"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNext}
                  className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/10 transition-all active:scale-95"
                  aria-label="Próximo combo"
                  title="Próximo combo"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setIsPaused((prev) => !prev)}
                  className={`p-2 rounded-xl border transition-all ${
                    isPaused 
                      ? 'bg-amber-500 text-zinc-950 border-amber-400 font-bold' 
                      : 'bg-white/10 hover:bg-white/20 text-white border-white/10'
                  }`}
                  aria-label={isPaused ? "Retomar looping" : "Pausar looping"}
                  title={isPaused ? "Retomar looping infinito" : "Pausar looping"}
                >
                  {isPaused ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4 fill-current" />}
                </button>
              </div>

              {/* Thumbnails strip showing all looping combos */}
              <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
                {combos.map((combo, idx) => {
                  const isActive = idx === currentIndex;
                  return (
                    <button
                      key={combo.id}
                      onClick={() => handleSelectThumbnail(idx)}
                      className={`flex items-center gap-2 px-2.5 py-1.5 rounded-xl border text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                        isActive
                          ? 'bg-red-600/40 border-red-500 text-white shadow-lg shadow-red-950/60 scale-105'
                          : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white hover:bg-white/10'
                      }`}
                    >
                      <img
                        src={combo.image}
                        alt={combo.name}
                        className="w-5 h-5 rounded-md object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=100&q=80";
                        }}
                      />
                      <span className="max-w-[100px] sm:max-w-[130px] truncate">{combo.name}</span>
                    </button>
                  );
                })}
              </div>

              {/* Dot Indicators */}
              <div className="hidden sm:flex items-center gap-1.5">
                {combos.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSelectThumbnail(idx)}
                    className={`h-1.5 rounded-full transition-all cursor-pointer ${
                      idx === currentIndex ? 'w-6 bg-[#E6392F]' : 'w-1.5 bg-white/25 hover:bg-white/40'
                    }`}
                    aria-label={`Ir para combo ${idx + 1}`}
                  />
                ))}
              </div>
            </div>

          </div>
        </div>

        {/* Continuous Infinite Marquee Ribbon of Combos & Deals */}
        <div className="mt-4 rounded-2xl bg-black/40 border border-white/5 py-2.5 overflow-hidden backdrop-blur-sm">
          <div className="animate-marquee items-center gap-8 text-xs font-bold tracking-wide">
            {/* Duplicated list to create the seamless infinite scroll effect */}
            {[...combos, ...combos].map((combo, i) => (
              <div
                key={`${combo.id}-${i}`}
                onClick={() => onSelectProduct(combo)}
                className="flex items-center gap-2 text-zinc-300 hover:text-amber-400 transition-colors cursor-pointer flex-shrink-0"
              >
                <span className="text-red-500">🔥</span>
                <span className="text-white font-extrabold">{combo.name}</span>
                <span className="text-[#FFC857] font-black">
                  R$ {(combo.promoPrice || combo.price).toFixed(2).replace('.', ',')}
                </span>
                <span className="text-zinc-600">•</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
