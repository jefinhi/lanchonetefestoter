import React, { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Sparkles, Flame, Eye } from 'lucide-react';
import { Product } from '../types';

interface NetflixRowProps {
  title: string;
  subtitle?: string;
  icon?: string;
  badgeText?: string;
  badgeColor?: string;
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onQuickAdd: (product: Product) => void;
}

export const NetflixRow: React.FC<NetflixRowProps> = ({
  title,
  subtitle,
  icon,
  badgeText,
  badgeColor = 'bg-red-500/20 text-red-400 border-red-500/30',
  products,
  onSelectProduct,
  onQuickAdd,
}) => {
  const rowRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  if (products.length === 0) return null;

  const checkScrollPosition = () => {
    if (rowRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = rowRef.current;
      setCanScrollLeft(scrollLeft > 20);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 20);
    }
  };

  const handleScroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const scrollAmount = rowRef.current.clientWidth * 0.75;
      rowRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
      setTimeout(checkScrollPosition, 350);
    }
  };

  return (
    <div className="relative py-6 group">
      {/* Row Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 mb-3 flex items-end justify-between">
        <div>
          <div className="flex items-center gap-2">
            {icon && <span className="text-xl">{icon}</span>}
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {title}
            </h2>
            {badgeText && (
              <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${badgeColor}`}>
                {badgeText}
              </span>
            )}
          </div>
          {subtitle && <p className="text-xs sm:text-sm text-zinc-400 mt-0.5">{subtitle}</p>}
        </div>

        {/* Desktop Quick Nav Controls */}
        <div className="hidden sm:flex items-center gap-1.5 opacity-80 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => handleScroll('left')}
            disabled={!canScrollLeft}
            className="p-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 disabled:opacity-30 disabled:pointer-events-none text-white border border-white/5 transition-all shadow-md active:scale-95"
            aria-label="Rolar para esquerda"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => handleScroll('right')}
            disabled={!canScrollRight}
            className="p-2 rounded-xl bg-zinc-800/80 hover:bg-zinc-700 disabled:opacity-30 disabled:pointer-events-none text-white border border-white/5 transition-all shadow-md active:scale-95"
            aria-label="Rolar para direita"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Netflix Horizontal Row Slider Container */}
      <div className="relative">
        {/* Floating Left Arrow Overlay */}
        {canScrollLeft && (
          <button
            onClick={() => handleScroll('left')}
            className="hidden md:flex absolute left-0 top-1/2 -translate-y-1/2 z-20 w-12 h-44 bg-gradient-to-r from-[#0D0D0E]/95 to-transparent items-center justify-start pl-2 text-white hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all duration-200"
            aria-label="Anterior"
          >
            <div className="p-2 rounded-full bg-black/70 border border-white/20 backdrop-blur-md">
              <ChevronLeft className="w-6 h-6" />
            </div>
          </button>
        )}

        {/* Floating Right Arrow Overlay */}
        {canScrollRight && (
          <button
            onClick={() => handleScroll('right')}
            className="hidden md:flex absolute right-0 top-1/2 -translate-y-1/2 z-20 w-12 h-44 bg-gradient-to-l from-[#0D0D0E]/95 to-transparent items-center justify-end pr-2 text-white hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all duration-200"
            aria-label="Próximo"
          >
            <div className="p-2 rounded-full bg-black/70 border border-white/20 backdrop-blur-md">
              <ChevronRight className="w-6 h-6" />
            </div>
          </button>
        )}

        {/* Horizontal Scroll Track */}
        <div
          ref={rowRef}
          onScroll={checkScrollPosition}
          className="flex items-stretch gap-4 sm:gap-5 overflow-x-auto no-scrollbar px-4 sm:px-6 max-w-7xl mx-auto py-2"
        >
          {products.map((product) => {
            const hasPromo = !!product.promoPrice;
            const currentPrice = product.promoPrice || product.price;

            return (
              <div
                key={product.id}
                className="flex-none w-64 sm:w-72 flex flex-col justify-between rounded-2xl bg-[#16161A] border border-white/10 hover:border-red-500/50 hover:shadow-xl hover:shadow-red-950/20 transition-all duration-200 group/card overflow-hidden"
              >
                {/* Image Section */}
                <div 
                  className="relative h-44 sm:h-48 overflow-hidden cursor-pointer bg-zinc-900"
                  onClick={() => onSelectProduct(product)}
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover/card:scale-105 transition-transform duration-500"
                    loading="lazy"
                    onError={(e) => {
                      // Reliable fallback image based on category
                      const fallback = product.category === 'pizzas'
                        ? 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=600&q=80'
                        : product.category === 'salgados'
                        ? 'https://images.unsplash.com/photo-1625813506062-0aeb1d7a094b?auto=format&fit=crop&w=600&q=80'
                        : product.category === 'bebidas' 
                        ? 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=600&q=80'
                        : product.category === 'hotdogs'
                        ? 'https://images.unsplash.com/photo-1619740455993-9e612b1af08a?auto=format&fit=crop&w=600&q=80'
                        : 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=600&q=80';
                      (e.target as HTMLImageElement).src = fallback;
                    }}
                  />

                  {/* Gradient overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#16161A] via-transparent to-black/30 pointer-events-none" />

                  {/* Badges */}
                  <div className="absolute top-2.5 left-2.5 flex flex-col gap-1.5 items-start z-10 pointer-events-none">
                    {product.badge && (
                      <span className="px-2.5 py-0.5 rounded-md bg-red-600 text-white font-bold text-[10px] tracking-wide uppercase shadow-md shadow-red-950/60">
                        {product.badge}
                      </span>
                    )}
                    {product.isVegetarian && (
                      <span className="px-2 py-0.5 rounded-md bg-emerald-700/90 text-white font-bold text-[10px] tracking-wide shadow-md flex items-center gap-1">
                        🌱 VEGETARIANO
                      </span>
                    )}
                  </div>

                  {/* Promo Save Tag */}
                  {hasPromo && (
                    <div className="absolute top-2.5 right-2.5 z-10">
                      <span className="px-2 py-0.5 rounded-md bg-amber-400 text-zinc-950 font-black text-[10px] shadow-md">
                        OFERTA
                      </span>
                    </div>
                  )}

                  {/* Quick Preview Hover Overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/card:opacity-100 transition-opacity flex items-center justify-center pointer-events-none">
                    <span className="px-3 py-1.5 rounded-xl bg-white/95 text-zinc-900 font-bold text-xs shadow-lg flex items-center gap-1.5 transform translate-y-1 group-hover/card:translate-y-0 transition-transform">
                      <Eye className="w-3.5 h-3.5" /> Ver Detalhes
                    </span>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 
                      onClick={() => onSelectProduct(product)}
                      className="font-bold text-white text-base hover:text-red-400 transition-colors cursor-pointer line-clamp-1 mb-1.5"
                      title={product.name}
                    >
                      {product.name}
                    </h3>
                    <p className="text-zinc-400 text-xs line-clamp-2 leading-relaxed mb-3">
                      {product.description}
                    </p>
                  </div>

                  {/* Card Bottom: Price and CTA */}
                  <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-2 mt-auto">
                    <div>
                      {hasPromo && (
                        <span className="text-[11px] text-zinc-500 line-through block -mb-1">
                          R$ {product.price.toFixed(2).replace('.', ',')}
                        </span>
                      )}
                      <span className="text-lg font-black text-[#FFC857]">
                        R$ {currentPrice.toFixed(2).replace('.', ',')}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onSelectProduct(product)}
                        className="px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold transition-colors active:scale-95"
                        title="Ver opções e personalizar adicionais"
                      >
                        Opções
                      </button>
                      <button
                        id={`btn-add-netflix-${product.id}`}
                        onClick={() => onQuickAdd(product)}
                        className="p-2 rounded-xl bg-[#E6392F] hover:bg-red-600 text-white font-bold transition-all shadow-md shadow-red-950/50 active:scale-95"
                        title="Adicionar direto ao carrinho"
                        aria-label={`Adicionar ${product.name} ao carrinho`}
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
