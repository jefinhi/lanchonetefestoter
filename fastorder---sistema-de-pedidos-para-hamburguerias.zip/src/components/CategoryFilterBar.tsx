import React from 'react';
import { Search, X, Flame, Sparkles, Heart } from 'lucide-react';

export type FilterType = 
  | 'all' 
  | 'promo' 
  | 'vegetarian' 
  | 'popular' 
  | 'combos' 
  | 'hamburgueres' 
  | 'hotdogs' 
  | 'lanches' 
  | 'pizzas'
  | 'salgados'
  | 'porcoes' 
  | 'bebidas' 
  | 'sobremesas';

interface CategoryFilterBarProps {
  selectedFilter: FilterType;
  onSelectFilter: (filter: FilterType) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  totalProductsCount: number;
}

export const CategoryFilterBar: React.FC<CategoryFilterBarProps> = ({
  selectedFilter,
  onSelectFilter,
  searchQuery,
  onSearchChange,
  totalProductsCount,
}) => {
  const categories: { id: FilterType; label: string; icon?: string; badgeColor?: string }[] = [
    { id: 'all', label: 'Todos os Itens' },
    { id: 'promo', label: 'Promoções Especiais', icon: '🔥', badgeColor: 'text-red-400 bg-red-500/10' },
    { id: 'vegetarian', label: 'Opções Vegetarianas', icon: '🌱', badgeColor: 'text-emerald-400 bg-emerald-500/10' },
    { id: 'popular', label: 'Mais Pedidos', icon: '⭐' },
    { id: 'combos', label: 'Combos Completos', icon: '🍟' },
    { id: 'hamburgueres', label: 'Hambúrgueres', icon: '🍔' },
    { id: 'pizzas', label: 'Pizzas Artesanais', icon: '🍕' },
    { id: 'salgados', label: 'Salgados Fritos & Assados', icon: '🥟' },
    { id: 'hotdogs', label: 'Hot Dogs Especiais', icon: '🌭' },
    { id: 'lanches', label: 'Lanches Tradicionais', icon: '🥪' },
    { id: 'porcoes', label: 'Porções & Batatas', icon: '🍗' },
    { id: 'bebidas', label: 'Refrigerantes & Bebidas', icon: '🥤' },
    { id: 'sobremesas', label: 'Sobremesas & Shakes', icon: '🍰' },
  ];

  return (
    <div className="sticky top-16 z-30 bg-[#111113]/95 backdrop-blur-md border-b border-white/10 py-3 px-4 sm:px-6 shadow-md">
      <div className="max-w-7xl mx-auto flex flex-col gap-3">
        {/* Search Input Bar */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Buscar no cardápio: smash, x-tudo, bacon, coca, batata..."
              className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-zinc-900/90 border border-white/10 text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-[#E6392F] focus:border-transparent transition-all shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full text-zinc-400 hover:text-white bg-zinc-800"
                title="Limpar busca"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {searchQuery && (
            <span className="text-xs text-zinc-400 hidden sm:inline whitespace-nowrap">
              {totalProductsCount} resultado(s)
            </span>
          )}
        </div>

        {/* Netflix Horizontal Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {categories.map((cat) => {
            const isSelected = selectedFilter === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectFilter(cat.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-150 active:scale-95 ${
                  isSelected
                    ? 'bg-[#E6392F] text-white shadow-lg shadow-red-950/50 border border-red-400'
                    : 'bg-zinc-800/80 text-zinc-300 hover:text-white hover:bg-zinc-700/80 border border-white/5'
                }`}
              >
                {cat.icon && <span>{cat.icon}</span>}
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
