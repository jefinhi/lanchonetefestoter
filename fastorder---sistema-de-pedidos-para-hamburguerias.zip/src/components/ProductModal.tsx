import React, { useState, useEffect } from 'react';
import { X, Plus, Minus, Check, Sparkles, MessageSquare, AlertCircle } from 'lucide-react';
import { Product, Addon } from '../types';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (
    product: Product,
    quantity: number,
    selectedAddons: Addon[],
    removedIngredients: string[],
    notes: string,
    finalUnitPrice: number
  ) => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
}) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedAddons, setSelectedAddons] = useState<Addon[]>([]);
  const [removedIngredients, setRemovedIngredients] = useState<string[]>([]);
  const [notes, setNotes] = useState('');

  // Reset state whenever product changes
  useEffect(() => {
    if (product) {
      setQuantity(1);
      setSelectedAddons([]);
      setRemovedIngredients([]);
      setNotes('');
    }
  }, [product]);

  if (!product) return null;

  const basePrice = product.promoPrice || product.price;
  const addonsTotal = selectedAddons.reduce((sum, item) => sum + item.price, 0);
  const unitPrice = basePrice + addonsTotal;
  const totalPrice = unitPrice * quantity;

  const toggleAddon = (addon: Addon) => {
    setSelectedAddons((prev) => {
      const exists = prev.some((item) => item.id === addon.id);
      if (exists) {
        return prev.filter((item) => item.id !== addon.id);
      } else {
        return [...prev, addon];
      }
    });
  };

  const toggleRemoved = (ing: string) => {
    setRemovedIngredients((prev) => {
      if (prev.includes(ing)) {
        return prev.filter((i) => i !== ing);
      } else {
        return [...prev, ing];
      }
    });
  };

  const handleConfirm = () => {
    onAddToCart(product, quantity, selectedAddons, removedIngredients, notes, unitPrice);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#18181C] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/60 hover:bg-black/80 text-white border border-white/20 transition-all active:scale-95"
          aria-label="Fechar modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Scrollable Modal Content */}
        <div className="overflow-y-auto custom-scrollbar flex-1">
          {/* Product Header Image */}
          <div className="relative h-64 sm:h-72 w-full bg-zinc-900 overflow-hidden">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80";
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#18181C] via-[#18181C]/40 to-transparent" />

            {/* Badges in image */}
            <div className="absolute bottom-4 left-6 flex flex-wrap items-center gap-2">
              {product.badge && (
                <span className="px-3 py-1 rounded-full bg-red-600 text-white font-bold text-xs shadow-lg shadow-red-950/60">
                  {product.badge}
                </span>
              )}
              {product.isVegetarian && (
                <span className="px-3 py-1 rounded-full bg-emerald-700 text-white font-bold text-xs shadow-lg">
                  🌱 100% Vegetariano
                </span>
              )}
              {product.promoPrice && (
                <span className="px-3 py-1 rounded-full bg-amber-400 text-zinc-950 font-extrabold text-xs shadow-lg">
                  Economize R$ {(product.price - product.promoPrice).toFixed(2).replace('.', ',')}
                </span>
              )}
            </div>
          </div>

          {/* Product Info */}
          <div className="p-6">
            <div className="flex items-baseline justify-between gap-4 mb-2">
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                {product.name}
              </h2>
            </div>

            <p className="text-sm text-zinc-300 leading-relaxed mb-6">
              {product.description}
            </p>

            {/* Section 1: Addons (Personalize seu lanche) */}
            {product.availableAddons && product.availableAddons.length > 0 && (
              <div className="mb-6 pt-4 border-t border-white/10">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-400" />
                    Personalize com Adicionais
                  </h3>
                  <span className="text-xs text-zinc-400">Opcional</span>
                </div>

                <div className="space-y-2">
                  {product.availableAddons.map((addon) => {
                    const isSelected = selectedAddons.some((item) => item.id === addon.id);
                    return (
                      <label
                        key={addon.id}
                        className={`flex items-center justify-between p-3 rounded-2xl border cursor-pointer transition-all ${
                          isSelected
                            ? 'bg-red-500/10 border-red-500/50 text-white'
                            : 'bg-zinc-900/60 hover:bg-zinc-900 border-white/5 text-zinc-300'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => toggleAddon(addon)}
                            className="w-4 h-4 rounded border-zinc-700 text-red-600 focus:ring-red-500 bg-zinc-800"
                          />
                          <span className="text-sm font-medium">{addon.name}</span>
                        </div>
                        <span className="text-sm font-bold text-[#FFC857]">
                          + R$ {addon.price.toFixed(2).replace('.', ',')}
                        </span>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Section 2: Removable Ingredients */}
            {product.removableIngredients && product.removableIngredients.length > 0 && (
              <div className="mb-6 pt-4 border-t border-white/10">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-extrabold text-white uppercase tracking-wider flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-zinc-400" />
                    Remover Ingredientes
                  </h3>
                  <span className="text-xs text-zinc-400">Sem custo</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {product.removableIngredients.map((item) => {
                    const isRemoved = removedIngredients.includes(item);
                    return (
                      <label
                        key={item}
                        className={`flex items-center gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${
                          isRemoved
                            ? 'bg-zinc-800 border-amber-500/50 text-amber-300 line-through'
                            : 'bg-zinc-900/60 hover:bg-zinc-900 border-white/5 text-zinc-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isRemoved}
                          onChange={() => toggleRemoved(item)}
                          className="w-4 h-4 rounded border-zinc-700 text-amber-500 focus:ring-amber-400 bg-zinc-800"
                        />
                        <span className="text-xs sm:text-sm font-medium">{item}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Section 3: Observação do Pedido */}
            <div className="mb-4 pt-4 border-t border-white/10">
              <h3 className="text-sm font-extrabold text-white uppercase tracking-wider mb-2 flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-zinc-400" />
                Alguma Observação?
              </h3>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Exemplo: carne bem passada, molho à parte, cortar ao meio..."
                rows={2}
                className="w-full p-3 rounded-2xl bg-zinc-900/90 border border-white/10 text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-[#E6392F]"
              />
            </div>
          </div>
        </div>

        {/* Modal Sticky Footer: Quantity & Confirm Add to Cart */}
        <div className="p-4 sm:p-6 bg-[#121215] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Quantity Selector */}
          <div className="flex items-center gap-3 bg-zinc-900 p-1.5 rounded-2xl border border-white/10 w-full sm:w-auto justify-between sm:justify-start">
            <button
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              disabled={quantity <= 1}
              className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 disabled:opacity-40 text-white transition-colors"
              aria-label="Diminuir quantidade"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="font-extrabold text-base px-3 text-white min-w-[32px] text-center">
              {quantity}
            </span>
            <button
              onClick={() => setQuantity((q) => q + 1)}
              className="p-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white transition-colors"
              aria-label="Aumentar quantidade"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Add to Cart CTA Button */}
          <button
            id="btn-confirm-add-to-cart"
            onClick={handleConfirm}
            className="w-full sm:w-auto flex-1 px-6 py-4 rounded-2xl bg-gradient-to-r from-[#E6392F] to-[#c52c23] hover:from-[#f3453b] hover:to-[#d63229] text-white font-black text-sm sm:text-base shadow-xl shadow-red-950/50 hover:shadow-red-900/60 transition-all flex items-center justify-between gap-4 active:scale-95"
          >
            <span>ADICIONAR AO CARRINHO</span>
            <span className="bg-black/30 px-3 py-1 rounded-xl text-[#FFC857] font-extrabold">
              R$ {totalPrice.toFixed(2).replace('.', ',')}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
