import React, { useState } from 'react';
import { X, Send, MapPin, Store, CreditCard, Banknote, QrCode, AlertCircle, ArrowLeft, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem, RestaurantConfig, DeliveryType, PaymentMethod } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  config: RestaurantConfig;
  discountAmount: number;
  couponCode: string;
  onOrderCompleted: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  config,
  discountAmount,
  couponCode,
  onOrderCompleted,
}) => {
  // Customer details
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  
  // Delivery details
  const [deliveryType, setDeliveryType] = useState<DeliveryType>('delivery');
  const [street, setStreet] = useState('');
  const [number, setNumber] = useState('');
  const [neighborhood, setNeighborhood] = useState('');
  const [complement, setComplement] = useState('');
  const [city, setCity] = useState(config.city);
  const [reference, setReference] = useState('');

  // Payment details
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('pix');
  const [needChange, setNeedChange] = useState(false);
  const [changeFor, setChangeFor] = useState('');
  const [generalNotes, setGeneralNotes] = useState('');

  // Form error states
  const [errorMessage, setErrorMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0);
  const currentDeliveryFee = deliveryType === 'delivery' ? config.deliveryFee : 0;
  const finalTotal = Math.max(0, subtotal + currentDeliveryFee - discountAmount);

  const formatPhone = (val: string) => {
    const numbers = val.replace(/\D/g, '');
    if (numbers.length <= 10) {
      return numbers.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3').trim();
    }
    return numbers.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3').trim();
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhone(e.target.value);
    setCustomerPhone(formatted);
  };

  const validateForm = () => {
    if (!customerName.trim()) {
      setErrorMessage('Por favor, informe seu Nome completo.');
      return false;
    }
    const cleanPhone = customerPhone.replace(/\D/g, '');
    if (cleanPhone.length < 10) {
      setErrorMessage('Por favor, informe um número de WhatsApp válido com DDD.');
      return false;
    }

    if (deliveryType === 'delivery') {
      if (!street.trim() || !number.trim() || !neighborhood.trim()) {
        setErrorMessage('Por favor, preencha a Rua, Número e Bairro para a entrega.');
        return false;
      }
    }

    if (paymentMethod === 'money' && needChange) {
      const changeNum = parseFloat(changeFor.replace(',', '.'));
      if (isNaN(changeNum) || changeNum <= finalTotal) {
        setErrorMessage(`O valor para troco deve ser maior que o total (R$ ${finalTotal.toFixed(2).replace('.', ',')}).`);
        return false;
      }
    }

    setErrorMessage('');
    return true;
  };

  const handleSendToWhatsApp = () => {
    if (!validateForm()) return;

    // Trigger celebratory confetti!
    try {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    // Format items text
    const itemsText = items.map((item) => {
      let line = `${item.quantity}x ${item.name} — R$ ${item.totalPrice.toFixed(2).replace('.', ',')}`;
      if (item.selectedAddons.length > 0) {
        line += `\n   + Adicionais: ${item.selectedAddons.map((a) => a.name).join(', ')}`;
      }
      if (item.removedIngredients.length > 0) {
        line += `\n   - Sem: ${item.removedIngredients.join(', ')}`;
      }
      if (item.notes) {
        line += `\n   Obs: ${item.notes}`;
      }
      return line;
    }).join('\n\n');

    // Payment label
    let paymentLabel = 'Pix';
    if (paymentMethod === 'money') {
      paymentLabel = needChange && changeFor ? `Dinheiro (Troco para R$ ${changeFor})` : 'Dinheiro (Sem troco)';
    } else if (paymentMethod === 'card_delivery') {
      paymentLabel = 'Cartão de Crédito/Débito (Levar maquininha na entrega)';
    } else if (paymentMethod === 'card_pickup') {
      paymentLabel = 'Cartão (Pagar na retirada)';
    }

    // Delivery text
    let deliveryInfo = '';
    if (deliveryType === 'delivery') {
      deliveryInfo = `🚚 *ENTREGA NO ENDEREÇO*\n` +
        `${street}, Nº ${number}${complement ? ` - ${complement}` : ''}\n` +
        `Bairro: ${neighborhood}\n` +
        `Cidade: ${city}` +
        (reference ? `\n📍 Referência: ${reference}` : '');
    } else {
      deliveryInfo = `🏪 *RETIRADA NO LOCAL*\n` +
        `Retirar em: ${config.address}, ${config.neighborhood}, ${config.city}\n` +
        `Tempo estimado: ${config.estimatedTime}`;
    }

    // Build the complete WhatsApp message adhering to PRD specs
    const message = 
      `🍔 *NOVO PEDIDO — ${config.name}*\n\n` +
      `Olá! Gostaria de confirmar meu pedido pelo cardápio online.\n\n` +
      `👤 *CLIENTE:* ${customerName.trim()}\n` +
      `📱 *WHATSAPP:* ${customerPhone.trim()}\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `🛒 *ITENS DO PEDIDO:*\n\n` +
      `${itemsText}\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `Subtotal: R$ ${subtotal.toFixed(2).replace('.', ',')}\n` +
      `Taxa de Entrega: R$ ${currentDeliveryFee.toFixed(2).replace('.', ',')}\n` +
      (discountAmount > 0 ? `Desconto (${couponCode}): -R$ ${discountAmount.toFixed(2).replace('.', ',')}\n` : '') +
      `💰 *TOTAL: R$ ${finalTotal.toFixed(2).replace('.', ',')}*\n\n` +
      `━━━━━━━━━━━━━━━━━━━━\n` +
      `${deliveryInfo}\n\n` +
      `💳 *FORMA DE PAGAMENTO:*\n${paymentLabel}\n` +
      (generalNotes ? `\n📝 *OBSERVAÇÕES GERAIS:*\n${generalNotes}\n` : '') +
      `\n━━━━━━━━━━━━━━━━━━━━\n` +
      `_Pedido gerado automaticamente pelo cardápio digital FastOrder._`;

    // Strip non digits for WhatsApp number
    const cleanWhatsapp = config.whatsapp.replace(/\D/g, '');
    const encodedMessage = encodeURIComponent(message);
    const waUrl = `https://wa.me/${cleanWhatsapp}?text=${encodedMessage}`;

    setIsSuccess(true);

    // Open WhatsApp in new tab or current
    setTimeout(() => {
      window.open(waUrl, '_blank');
      onOrderCompleted();
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#18181C] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 bg-[#121215] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-red-600/20 text-red-500 flex items-center justify-center font-bold">
              📝
            </div>
            <div>
              <h2 className="text-lg font-black text-white">Finalizar Pedido</h2>
              <p className="text-xs text-zinc-400">Preencha os dados para enviar direto ao WhatsApp da loja</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <div className="overflow-y-auto custom-scrollbar p-5 sm:p-6 space-y-6 flex-1">
          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-red-500/10 border border-red-500/40 text-red-300 text-xs flex items-center gap-2.5 animate-shake">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Section 1: Customer Data */}
          <div>
            <h3 className="text-xs font-black text-white uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px]">1</span>
              Seus Dados
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  Seu Nome Completo *
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Ex.: João da Silva"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">
                  WhatsApp com DDD *
                </label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={handlePhoneChange}
                  placeholder="(11) 99999-9999"
                  maxLength={15}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-900 border border-white/10 text-white text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Delivery or Pickup */}
          <div>
            <h3 className="text-xs font-black text-white uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px]">2</span>
              Como Deseja Receber?
            </h3>

            <div className="grid grid-cols-2 gap-3 mb-4">
              <button
                type="button"
                onClick={() => setDeliveryType('delivery')}
                className={`p-3.5 rounded-2xl border flex flex-col items-center text-center transition-all ${
                  deliveryType === 'delivery'
                    ? 'bg-red-600/15 border-red-500 text-white shadow-lg'
                    : 'bg-zinc-900/60 border-white/5 text-zinc-400 hover:text-white'
                }`}
              >
                <MapPin className={`w-5 h-5 mb-1 ${deliveryType === 'delivery' ? 'text-red-400' : 'text-zinc-500'}`} />
                <span className="text-xs font-bold">Entrega em Casa</span>
                <span className="text-[11px] text-zinc-400">Taxa: R$ {config.deliveryFee.toFixed(2).replace('.', ',')}</span>
              </button>

              <button
                type="button"
                onClick={() => setDeliveryType('pickup')}
                className={`p-3.5 rounded-2xl border flex flex-col items-center text-center transition-all ${
                  deliveryType === 'pickup'
                    ? 'bg-red-600/15 border-red-500 text-white shadow-lg'
                    : 'bg-zinc-900/60 border-white/5 text-zinc-400 hover:text-white'
                }`}
              >
                <Store className={`w-5 h-5 mb-1 ${deliveryType === 'pickup' ? 'text-red-400' : 'text-zinc-500'}`} />
                <span className="text-xs font-bold">Retirar na Loja</span>
                <span className="text-[11px] text-emerald-400 font-semibold">Sem taxa (Grátis)</span>
              </button>
            </div>

            {/* Delivery address fields */}
            {deliveryType === 'delivery' ? (
              <div className="space-y-3 p-4 rounded-2xl bg-zinc-900/50 border border-white/5">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-semibold text-zinc-300 mb-1">
                      Rua / Avenida *
                    </label>
                    <input
                      type="text"
                      value={street}
                      onChange={(e) => setStreet(e.target.value)}
                      placeholder="Ex: Rua das Flores"
                      className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-white text-xs focus:ring-1 focus:ring-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1">
                      Número *
                    </label>
                    <input
                      type="text"
                      value={number}
                      onChange={(e) => setNumber(e.target.value)}
                      placeholder="Ex: 123"
                      className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-white text-xs focus:ring-1 focus:ring-red-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1">
                      Bairro *
                    </label>
                    <input
                      type="text"
                      value={neighborhood}
                      onChange={(e) => setNeighborhood(e.target.value)}
                      placeholder="Ex: Centro"
                      className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-white text-xs focus:ring-1 focus:ring-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-zinc-300 mb-1">
                      Complemento (Apto, Bloco)
                    </label>
                    <input
                      type="text"
                      value={complement}
                      onChange={(e) => setComplement(e.target.value)}
                      placeholder="Ex: Apto 42 Bloco B"
                      className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-white text-xs focus:ring-1 focus:ring-red-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-zinc-300 mb-1">
                    Ponto de Referência
                  </label>
                  <input
                    type="text"
                    value={reference}
                    onChange={(e) => setReference(e.target.value)}
                    placeholder="Ex: Próximo à praça principal, portão branco..."
                    className="w-full px-3 py-2 rounded-xl bg-zinc-900 border border-white/10 text-white text-xs focus:ring-1 focus:ring-red-500"
                  />
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-zinc-900/60 border border-white/5 space-y-1 text-xs">
                <p className="font-bold text-white flex items-center gap-1.5">
                  <Store className="w-4 h-4 text-amber-400" />
                  Local de Retirada:
                </p>
                <p className="text-zinc-300">{config.address}, {config.neighborhood} - {config.city}</p>
                <p className="text-zinc-400">Tempo estimado: <strong>{config.estimatedTime}</strong></p>
              </div>
            )}
          </div>

          {/* Section 3: Payment Method */}
          <div>
            <h3 className="text-xs font-black text-white uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-600 text-white flex items-center justify-center text-[10px]">3</span>
              Forma de Pagamento
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mb-3">
              <button
                type="button"
                onClick={() => setPaymentMethod('pix')}
                className={`p-3 rounded-2xl border flex flex-col items-center text-center transition-all ${
                  paymentMethod === 'pix'
                    ? 'bg-red-600/15 border-red-500 text-white'
                    : 'bg-zinc-900/60 border-white/5 text-zinc-400 hover:text-white'
                }`}
              >
                <QrCode className="w-5 h-5 mb-1 text-emerald-400" />
                <span className="text-xs font-bold">PIX</span>
                <span className="text-[10px] text-emerald-400">Aprovação rápida</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod(deliveryType === 'delivery' ? 'card_delivery' : 'card_pickup')}
                className={`p-3 rounded-2xl border flex flex-col items-center text-center transition-all ${
                  paymentMethod.startsWith('card')
                    ? 'bg-red-600/15 border-red-500 text-white'
                    : 'bg-zinc-900/60 border-white/5 text-zinc-400 hover:text-white'
                }`}
              >
                <CreditCard className="w-5 h-5 mb-1 text-amber-400" />
                <span className="text-xs font-bold">Cartão</span>
                <span className="text-[10px] text-zinc-400">Débito / Crédito</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod('money')}
                className={`p-3 rounded-2xl border flex flex-col items-center text-center transition-all ${
                  paymentMethod === 'money'
                    ? 'bg-red-600/15 border-red-500 text-white'
                    : 'bg-zinc-900/60 border-white/5 text-zinc-400 hover:text-white'
                }`}
              >
                <Banknote className="w-5 h-5 mb-1 text-green-400" />
                <span className="text-xs font-bold">Dinheiro</span>
                <span className="text-[10px] text-zinc-400">Na entrega</span>
              </button>
            </div>

            {/* If Pix selected: Info */}
            {paymentMethod === 'pix' && (
              <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-emerald-200 text-xs flex items-center justify-between">
                <div>
                  <p className="font-bold">Chave PIX da Loja:</p>
                  <p className="text-zinc-300 font-mono text-[11px] select-all">{config.pixKey}</p>
                </div>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-1 rounded-lg">
                  Pagar após envio
                </span>
              </div>
            )}

            {/* If Money selected: Troco */}
            {paymentMethod === 'money' && (
              <div className="p-3 rounded-xl bg-zinc-900/80 border border-white/5 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-zinc-300">Precisa de troco?</span>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setNeedChange(false)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold ${
                        !needChange ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      Não
                    </button>
                    <button
                      type="button"
                      onClick={() => setNeedChange(true)}
                      className={`px-3 py-1 rounded-lg text-xs font-bold ${
                        needChange ? 'bg-red-600 text-white' : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      Sim
                    </button>
                  </div>
                </div>

                {needChange && (
                  <div>
                    <label className="block text-[11px] text-zinc-400 mb-1">
                      Troco para quanto em dinheiro? (R$)
                    </label>
                    <input
                      type="text"
                      value={changeFor}
                      onChange={(e) => setChangeFor(e.target.value)}
                      placeholder="Ex: 100,00"
                      className="w-full px-3 py-1.5 rounded-lg bg-zinc-800 border border-white/10 text-white text-xs focus:ring-1 focus:ring-red-500"
                    />
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Section 4: General Notes */}
          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1">
              Observações Gerais do Pedido (Opcional)
            </label>
            <input
              type="text"
              value={generalNotes}
              onChange={(e) => setGeneralNotes(e.target.value)}
              placeholder="Ex.: Tocar campainha número 2, sem contato..."
              className="w-full px-3.5 py-2 rounded-xl bg-zinc-900 border border-white/10 text-white text-xs focus:ring-1 focus:ring-red-500"
            />
          </div>
        </div>

        {/* Modal Sticky Footer */}
        <div className="p-4 sm:p-5 bg-[#121215] border-t border-white/10 space-y-3">
          <div className="flex items-baseline justify-between text-sm">
            <span className="text-zinc-400">Total a Pagar:</span>
            <span className="text-2xl font-black text-[#FFC857]">
              R$ {finalTotal.toFixed(2).replace('.', ',')}
            </span>
          </div>

          <button
            id="btn-send-whatsapp-order"
            onClick={handleSendToWhatsApp}
            disabled={isSuccess}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-[#25D366] to-[#1EBE5D] hover:from-[#2cf074] hover:to-[#22d166] text-white font-black text-sm sm:text-base shadow-xl shadow-green-950/60 transition-all flex items-center justify-center gap-2.5 active:scale-95"
          >
            {isSuccess ? (
              <>
                <CheckCircle2 className="w-5 h-5 animate-bounce" />
                <span>ENVIANDO PEDIDO...</span>
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                <span>ENVIAR PEDIDO PELO WHATSAPP</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
