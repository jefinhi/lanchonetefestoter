import React, { useRef, useState } from 'react';
import { Star, ChevronLeft, ChevronRight, ThumbsUp, CheckCircle2, MessageCircle, Sparkles, Quote } from 'lucide-react';

interface Testimonial {
  id: string;
  name: string;
  role: string;
  bairro: string;
  avatarText: string;
  avatarColor: string;
  text: string;
  rating: number;
  productOrdered: string;
  highlightBadge: string;
  timeAgo: string;
  deliveryTime: string;
}

export const Testimonials: React.FC = () => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);
  const [activeFilter, setActiveFilter] = useState<string>('todos');

  const testimonials: Testimonial[] = [
    {
      id: '1',
      name: 'Mariana Silva',
      role: 'Cliente Frequente',
      bairro: 'Centro',
      avatarText: 'MS',
      avatarColor: 'from-red-600 to-rose-700',
      text: 'O Combo Bacon Supreme é simplesmente surreal! Pão macio selado na manteiga, carne suculenta e o bacon super crocante. Chegou em 24 minutos trincando de quente!',
      rating: 5,
      productOrdered: 'Combo Bacon Supreme',
      highlightBadge: '⭐ TOP AVALIAÇÃO',
      timeAgo: 'Ontem',
      deliveryTime: '24 min',
    },
    {
      id: '2',
      name: 'Lucas Ferreira',
      role: 'Pediu pelo WhatsApp',
      bairro: 'Jardim das Flores',
      avatarText: 'LF',
      avatarColor: 'from-amber-500 to-orange-600',
      text: 'Melhor X-Tudo da região! Pedi com ovo e maionese verde artesanal, sem cebola, e veio exatamente como personalizei no site. Sistema de pedido nota 1000.',
      rating: 5,
      productOrdered: 'X-Tudo Supremo',
      highlightBadge: '🔥 MAIS PEDIDO',
      timeAgo: 'Há 2 dias',
      deliveryTime: '28 min',
    },
    {
      id: '3',
      name: 'Camila Mendes',
      role: 'Delivery em Casa',
      bairro: 'Vila Mariana',
      avatarText: 'CM',
      avatarColor: 'from-emerald-600 to-teal-700',
      text: 'Amei as opções vegetarianas! O burger de shimeji com falafel é super temperado e a batata com cheddar é um vício. Finalmente um lugar que respeita quem não come carne!',
      rating: 5,
      productOrdered: 'Burger Veggie Shimeji',
      highlightBadge: '🌱 VEGGIE LOVER',
      timeAgo: 'Há 3 dias',
      deliveryTime: '30 min',
    },
    {
      id: '4',
      name: 'Rodrigo Alcantara',
      role: 'Fã de Dogão',
      bairro: 'Bela Vista',
      avatarText: 'RA',
      avatarColor: 'from-blue-600 to-indigo-700',
      text: 'O Hot Dog Prensado Paulista superou todas as expectativas! Purê cremoso de verdade, duas salsichas e prensado na chapa com perfeição. Virou meu lanche padrão de domingo.',
      rating: 5,
      productOrdered: 'Hot Dog Especial Duplo',
      highlightBadge: '🌭 NOVO FAVORITO',
      timeAgo: 'Há 4 dias',
      deliveryTime: '22 min',
    },
    {
      id: '5',
      name: 'Beatriz Souza',
      role: 'Noite em Família',
      bairro: 'Santa Tereza',
      avatarText: 'BS',
      avatarColor: 'from-purple-600 to-pink-700',
      text: 'Pedimos o Combo Família no sábado. 4 burgers impecáveis, batata crocante mesmo após a entrega e refrigerante bem gelado. Custo-benefício imbatível!',
      rating: 5,
      productOrdered: 'Combo Família 4x',
      highlightBadge: '👨‍👩‍👧‍👦 COMBO FAMÍLIA',
      timeAgo: 'Há 5 dias',
      deliveryTime: '32 min',
    },
    {
      id: '6',
      name: 'Guilherme Santos',
      role: 'Amante de Smash',
      bairro: 'São Pedro',
      avatarText: 'GS',
      avatarColor: 'from-amber-600 to-red-700',
      text: 'O Smash Burger Duplo é uma obra de arte: aquela crostinha caramelizada perfeita e o cheddar derretendo. Pedido pelo site foi super intuitivo e sem travar.',
      rating: 5,
      productOrdered: 'Burger Smash Clássico',
      highlightBadge: '🍔 SMASH PERFEITO',
      timeAgo: 'Há 6 dias',
      deliveryTime: '20 min',
    },
    {
      id: '7',
      name: 'Fernanda Lima',
      role: 'Pedido no Trabalho',
      bairro: 'Parque Industrial',
      avatarText: 'FL',
      avatarColor: 'from-cyan-600 to-blue-700',
      text: 'A maionese da casa e a porção de batatas com cheddar e bacon são espetaculares. Toda sexta-feira a galera da empresa pede aqui e sempre chega quentinho.',
      rating: 5,
      productOrdered: 'Batata Rústica c/ Cheddar',
      highlightBadge: '🍟 CROCANTE & QUENTE',
      timeAgo: 'Há 1 semana',
      deliveryTime: '25 min',
    },
    {
      id: '8',
      name: 'Thiago Meireles',
      role: 'Cliente VIP',
      bairro: 'Jardins',
      avatarText: 'TM',
      avatarColor: 'from-rose-600 to-amber-700',
      text: 'Facilidade incrível para pedir pelo cardápio e mandar direto no WhatsApp. O atendente já confirmou os adicionais na hora e o motoboy foi muito educado!',
      rating: 5,
      productOrdered: 'X-Bacon Tradicional',
      highlightBadge: '⚡ RAPIDEZ TOTAL',
      timeAgo: 'Há 1 semana',
      deliveryTime: '23 min',
    },
  ];

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 15);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 15);
    }
  };

  const handleScroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const distance = scrollRef.current.clientWidth * 0.8;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -distance : distance,
        behavior: 'smooth',
      });
      setTimeout(checkScroll, 300);
    }
  };

  const filteredTestimonials = testimonials.filter((t) => {
    if (activeFilter === 'combos') return t.productOrdered.toLowerCase().includes('combo');
    if (activeFilter === 'burgers') return t.productOrdered.toLowerCase().includes('burger') || t.productOrdered.toLowerCase().includes('x-');
    if (activeFilter === 'hotdogs') return t.productOrdered.toLowerCase().includes('dog');
    return true;
  });

  return (
    <section className="py-12 bg-gradient-to-b from-[#0D0D0E] via-[#111115] to-[#0A0A0C] border-t border-white/5 relative overflow-hidden group/section">
      {/* Ambient background glow */}
      <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-96 h-96 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 relative">
        {/* Netflix-Style Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2.5 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-md bg-[#E6392F] text-white font-black text-[11px] tracking-wider uppercase shadow-md shadow-red-900/40">
                ★ 4.9 DE 5.0
              </span>
              <span className="flex items-center gap-1 text-emerald-400 font-bold text-xs">
                <CheckCircle2 className="w-3.5 h-3.5" />
                99% de Clientes Recomendam
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
              <span>Depoimentos em Destaque</span>
              <span className="text-lg text-amber-400 font-medium hidden sm:inline">• Experiências Reais</span>
            </h2>
            <p className="text-xs sm:text-sm text-zinc-400 mt-1 max-w-xl">
              Deslize para ver o que os apaixonados pelos nossos lanches dizem sobre sabor, qualidade e agilidade da entrega.
            </p>
          </div>

          {/* Quick Filter Tags & Navigation arrows */}
          <div className="flex items-center gap-2 self-start md:self-end">
            <div className="flex items-center gap-1.5 p-1 rounded-xl bg-zinc-900/80 border border-white/5 text-xs">
              <button
                onClick={() => setActiveFilter('todos')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeFilter === 'todos'
                    ? 'bg-[#E6392F] text-white shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Todos
              </button>
              <button
                onClick={() => setActiveFilter('burgers')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeFilter === 'burgers'
                    ? 'bg-[#E6392F] text-white shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Burgers
              </button>
              <button
                onClick={() => setActiveFilter('combos')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeFilter === 'combos'
                    ? 'bg-[#E6392F] text-white shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Combos
              </button>
              <button
                onClick={() => setActiveFilter('hotdogs')}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  activeFilter === 'hotdogs'
                    ? 'bg-[#E6392F] text-white shadow'
                    : 'text-zinc-400 hover:text-white'
                }`}
              >
                Hot Dogs
              </button>
            </div>

            {/* Desktop Navigation Arrows */}
            <div className="hidden sm:flex items-center gap-1 pl-2">
              <button
                id="btn-testimonials-prev"
                onClick={() => handleScroll('left')}
                disabled={!canScrollLeft}
                aria-label="Ver depoimentos anteriores"
                className={`p-2 rounded-xl border transition-all ${
                  canScrollLeft
                    ? 'bg-zinc-800 hover:bg-zinc-700 text-white border-white/10 shadow-lg'
                    : 'bg-zinc-900/50 text-zinc-600 border-white/5 cursor-not-allowed opacity-40'
                }`}
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                id="btn-testimonials-next"
                onClick={() => handleScroll('right')}
                disabled={!canScrollRight}
                aria-label="Ver próximos depoimentos"
                className={`p-2 rounded-xl border transition-all ${
                  canScrollRight
                    ? 'bg-zinc-800 hover:bg-zinc-700 text-white border-white/10 shadow-lg'
                    : 'bg-zinc-900/50 text-zinc-600 border-white/5 cursor-not-allowed opacity-40'
                }`}
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Netflix Carousel Track */}
        <div className="relative">
          {/* Edge fade gradient masks */}
          {canScrollLeft && (
            <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-[#0D0D0E] to-transparent z-20 pointer-events-none hidden sm:block" />
          )}
          {canScrollRight && (
            <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-[#0D0D0E] to-transparent z-20 pointer-events-none hidden sm:block" />
          )}

          {/* Left Arrow Floating Button on Hover */}
          {canScrollLeft && (
            <button
              onClick={() => handleScroll('left')}
              className="absolute left-1 top-1/2 -translate-y-1/2 z-30 p-3 rounded-full bg-black/90 hover:bg-red-600 text-white border border-white/20 shadow-2xl backdrop-blur-md opacity-0 group-hover/section:opacity-100 transition-all hover:scale-110 hidden sm:flex items-center justify-center"
              aria-label="Rolar para esquerda"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}

          {/* Right Arrow Floating Button on Hover */}
          {canScrollRight && (
            <button
              onClick={() => handleScroll('right')}
              className="absolute right-1 top-1/2 -translate-y-1/2 z-30 p-3 rounded-full bg-black/90 hover:bg-red-600 text-white border border-white/20 shadow-2xl backdrop-blur-md opacity-0 group-hover/section:opacity-100 transition-all hover:scale-110 hidden sm:flex items-center justify-center"
              aria-label="Rolar para direita"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          )}

          {/* Scrollable Container */}
          <div
            ref={scrollRef}
            onScroll={checkScroll}
            className="flex gap-4 sm:gap-5 overflow-x-auto scrollbar-none scroll-smooth pb-4 pt-2 -mx-4 sm:mx-0 px-4 sm:px-0"
            style={{ scrollSnapType: 'x mandatory' }}
          >
            {filteredTestimonials.map((review) => (
              <div
                key={review.id}
                className="w-[290px] sm:w-[350px] md:w-[380px] flex-shrink-0 flex flex-col justify-between p-5 rounded-2xl bg-[#16161A] border border-white/10 hover:border-red-500/40 hover:shadow-2xl hover:shadow-red-950/30 transition-all duration-300 hover:-translate-y-1.5 group/card"
                style={{ scrollSnapAlign: 'start' }}
              >
                {/* Top card bar: Customer info + badge */}
                <div>
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-3">
                      {/* Avatar initial badge */}
                      <div
                        className={`w-10 h-10 rounded-xl bg-gradient-to-br ${review.avatarColor} text-white font-black text-sm flex items-center justify-center shadow-md flex-shrink-0`}
                      >
                        {review.avatarText}
                      </div>

                      <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-extrabold text-white text-sm group-hover/card:text-red-400 transition-colors">
                            {review.name}
                          </h4>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" title="Cliente Verificado" />
                        </div>
                        <span className="text-[11px] text-zinc-400 block">
                          {review.bairro} • <strong className="text-zinc-300 font-semibold">{review.role}</strong>
                        </span>
                      </div>
                    </div>

                    <span className="px-2 py-0.5 rounded-md bg-red-500/15 border border-red-500/30 text-red-300 font-extrabold text-[10px] tracking-wide whitespace-nowrap">
                      {review.highlightBadge}
                    </span>
                  </div>

                  {/* Stars + Delivery Speed pill */}
                  <div className="flex items-center justify-between gap-2 mb-3 pt-1 border-t border-white/5">
                    <div className="flex items-center gap-1 text-amber-400">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                      ))}
                      <span className="text-xs font-black text-amber-300 ml-1">5.0</span>
                    </div>

                    <span className="text-[11px] font-semibold text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded-md border border-emerald-500/20">
                      ⚡ Entregue em {review.deliveryTime}
                    </span>
                  </div>

                  {/* Quote & Review Body */}
                  <div className="relative mb-4">
                    <Quote className="w-5 h-5 text-red-500/20 absolute -top-1 -left-1 pointer-events-none" />
                    <p className="text-xs sm:text-sm text-zinc-300 leading-relaxed italic pl-3 border-l-2 border-red-500/30">
                      "{review.text}"
                    </p>
                  </div>
                </div>

                {/* Card Footer: Product ordered tag + recommendation */}
                <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-1.5 text-zinc-300 overflow-hidden">
                    <span className="px-2 py-0.5 rounded-lg bg-zinc-800/80 border border-white/5 text-[11px] font-medium text-amber-300 truncate">
                      🍔 {review.productOrdered}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-zinc-400 text-[11px] flex-shrink-0">
                    <ThumbsUp className="w-3 h-3 text-emerald-400" />
                    <span>Recomenda</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Bar: Trust Metrics & WhatsApp CTA */}
        <div className="mt-6 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-400">
          <div className="flex items-center gap-4 flex-wrap justify-center sm:justify-start">
            <span className="flex items-center gap-1.5 text-zinc-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Mais de <strong>1.500 avaliações 5 estrelas</strong></span>
            </span>
            <span className="hidden sm:inline text-zinc-700">•</span>
            <span className="text-zinc-300">
              Tempo médio de entrega: <strong className="text-emerald-400">25 a 35 min</strong>
            </span>
          </div>

          <div className="text-center sm:text-right">
            <span className="text-[11px] text-zinc-500">
              Quer ver seu depoimento aqui? Envie pelo WhatsApp após receber seu pedido!
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};

