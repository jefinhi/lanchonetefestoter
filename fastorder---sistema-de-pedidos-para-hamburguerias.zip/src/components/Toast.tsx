import React, { useEffect } from 'react';
import { CheckCircle2, ShoppingBag } from 'lucide-react';

interface ToastProps {
  message: string;
  onClose: () => void;
  onOpenCart?: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, onClose, onOpenCart }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3200);
    return () => clearTimeout(timer);
  }, [message, onClose]);

  if (!message) return null;

  return (
    <div className="fixed top-20 right-4 sm:right-6 z-50 animate-in slide-in-from-top-4 fade-in duration-200">
      <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-[#16161A] border border-emerald-500/40 shadow-2xl text-white text-xs sm:text-sm">
        <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
        <span className="font-semibold text-zinc-200">{message}</span>
        {onOpenCart && (
          <button
            onClick={() => {
              onClose();
              onOpenCart();
            }}
            className="ml-2 px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center gap-1 shadow-sm"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Ver</span>
          </button>
        )}
      </div>
    </div>
  );
};
