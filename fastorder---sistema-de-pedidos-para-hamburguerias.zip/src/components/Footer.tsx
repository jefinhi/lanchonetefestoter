import React from 'react';
import { Phone, MapPin, Clock, Instagram, Heart } from 'lucide-react';
import { RestaurantConfig } from '../types';

interface FooterProps {
  config: RestaurantConfig;
}

export const Footer: React.FC<FooterProps> = ({ config }) => {
  return (
    <footer className="bg-[#0A0A0C] border-t border-white/10 text-zinc-400 text-xs sm:text-sm pt-12 pb-24 sm:pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Col 1: Brand */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🍔</span>
              <span className="font-extrabold text-lg text-white">{config.name}</span>
            </div>
            <p className="text-xs text-zinc-400 leading-relaxed">
              {config.slogan}. Pedidos práticos, rápidos e automáticos direto no seu WhatsApp.
            </p>
          </div>

          {/* Col 2: Contato & WhatsApp */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Contato & Pedidos</h4>
            <p className="flex items-center gap-2 text-xs">
              <Phone className="w-3.5 h-3.5 text-red-500" />
              <span>WhatsApp: <strong>{config.phone}</strong></span>
            </p>
            <p className="flex items-center gap-2 text-xs">
              <Instagram className="w-3.5 h-3.5 text-pink-500" />
              <span>Instagram: <strong>{config.instagram}</strong></span>
            </p>
            <p className="flex items-start gap-2 text-xs">
              <MapPin className="w-3.5 h-3.5 text-amber-500 flex-shrink-0 mt-0.5" />
              <span>{config.address}, {config.neighborhood}, {config.city}</span>
            </p>
          </div>

          {/* Col 3: Horário de Funcionamento */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Horários</h4>
            <p className="flex items-center gap-2 text-xs text-zinc-300">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              <span>{config.openingHoursText}</span>
            </p>
            <p className="text-xs text-zinc-500">
              Entregas e retiradas durante todo o expediente de funcionamento.
            </p>
          </div>

          {/* Col 4: Formas de Pagamento */}
          <div className="space-y-2.5">
            <h4 className="font-bold text-white text-xs uppercase tracking-wider">Formas de Pagamento</h4>
            <div className="flex flex-wrap gap-2 pt-1">
              <span className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-white/5 text-xs text-emerald-300">
                ⚡ Pix Instantâneo
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-white/5 text-xs text-zinc-300">
                💳 Cartão Crédito/Débito
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-white/5 text-xs text-zinc-300">
                💵 Dinheiro c/ Troco
              </span>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
          <p>© {new Date().getFullYear()} {config.name}. Todos os direitos reservados.</p>
          <p className="flex items-center gap-1">
            Feito com <Heart className="w-3 h-3 text-red-500 fill-red-500" /> para os amantes de lanches e burgers.
          </p>
        </div>
      </div>
    </footer>
  );
};
